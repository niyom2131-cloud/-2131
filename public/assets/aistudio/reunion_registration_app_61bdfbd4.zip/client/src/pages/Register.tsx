import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  NNSKHS2131_NAMES,
  NNSKHS2131_NAME_COUNT,
} from "@/data/nnskhs2131Names";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import {
  ArrowLeft,
  Upload,
  X,
  CheckCircle2,
  User,
  Phone,
  MapPin,
  CreditCard,
  MessageSquare,
  Shield,
} from "lucide-react";

const PROVINCES = [
  "กรุงเทพมหานคร",
  "กระบี่",
  "กาญจนบุรี",
  "กาฬสินธุ์",
  "กำแพงเพชร",
  "ขอนแก่น",
  "จันทบุรี",
  "ฉะเชิงเทรา",
  "ชลบุรี",
  "ชัยนาท",
  "ชัยภูมิ",
  "ชุมพร",
  "เชียงราย",
  "เชียงใหม่",
  "ตรัง",
  "ตราด",
  "ตาก",
  "นครนายก",
  "นครปฐม",
  "นครพนม",
  "นครราชสีมา",
  "นครศรีธรรมราช",
  "นครสวรรค์",
  "นนทบุรี",
  "นราธิวาส",
  "น่าน",
  "บึงกาฬ",
  "บุรีรัมย์",
  "ปทุมธานี",
  "ประจวบคีรีขันธ์",
  "ปราจีนบุรี",
  "ปัตตานี",
  "พระนครศรีอยุธยา",
  "พะเยา",
  "พังงา",
  "พัทลุง",
  "พิจิตร",
  "พิษณุโลก",
  "เพชรบุรี",
  "เพชรบูรณ์",
  "แพร่",
  "ภูเก็ต",
  "มหาสารคาม",
  "มุกดาหาร",
  "แม่ฮ่องสอน",
  "ยโสธร",
  "ยะลา",
  "ร้อยเอ็ด",
  "ระนอง",
  "ระยอง",
  "ราชบุรี",
  "ลพบุรี",
  "ลำปาง",
  "ลำพูน",
  "เลย",
  "ศรีสะเกษ",
  "สกลนคร",
  "สงขลา",
  "สตูล",
  "สมุทรปราการ",
  "สมุทรสงคราม",
  "สมุทรสาคร",
  "สระแก้ว",
  "สระบุรี",
  "สิงห์บุรี",
  "สุโขทัย",
  "สุพรรณบุรี",
  "สุราษฎร์ธานี",
  "สุรินทร์",
  "หนองคาย",
  "หนองบัวลำภู",
  "อ่างทอง",
  "อำนาจเจริญ",
  "อุดรธานี",
  "อุตรดิตถ์",
  "อุทัยธานี",
  "อุบลราชธานี",
];

const MILITARY_RANKS = [
  "พล.อ.",
  "พล.อ.อ.",
  "พล.ร.อ.",
  "พล.ท.",
  "พล.อ.ท.",
  "พล.ร.ท.",
  "พล.ต.",
  "พล.อ.ต.",
  "พล.ร.ต.",
  "พ.อ.",
  "น.อ.",
  "น.อ.(พิเศษ)",
  "พ.ท.",
  "น.ท.",
  "พ.ต.",
  "น.ต.",
  "ร.อ.",
  "ร.ต.อ.",
  "จ.อ.",
  "ร.ท.",
  "ร.ต.ท.",
  "จ.ท.",
  "ร.ต.",
  "ร.ต.ต.",
  "จ.ต.",
  "จ.ส.อ.",
  "จ.ส.ท.",
  "จ.ส.ต.",
  "ส.อ.",
  "ส.ท.",
  "ส.ต.",
  "พลฯ",
  "พลทหาร",
  "นาย",
  "นาง",
  "นางสาว",
  "-",
];

const schema = z.object({
  rank: z.string().optional(),
  fullName: z.string().min(2, "กรุณากรอกชื่อ-นามสกุล"),
  nickname: z.string().optional(),
  phone: z.string().min(9, "กรุณากรอกเบอร์โทรศัพท์ที่ถูกต้อง"),
  lineId: z.string().optional(),
  province: z.string().optional(),
  guestCount: z.number().min(0).max(10).optional().default(0),
  message: z.string().optional(),
  paymentAmount: z.number().optional(),
  paymentDate: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

export default function Register() {
  const [, navigate] = useLocation();
  const [step, setStep] = useState(1);
  const [slipFile, setSlipFile] = useState<File | null>(null);
  const [slipPreview, setSlipPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const {
    register,
    handleSubmit,
    watch,
    setValue,
    trigger,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(schema) as any,
    defaultValues: { guestCount: 0, rank: "" },
  });

  const createMutation = trpc.registration.create.useMutation({
    onSuccess: data => {
      navigate(`/thank-you/${data.id}`);
    },
    onError: err => {
      toast.error("เกิดข้อผิดพลาด: " + err.message);
    },
  });

  const handleSlipChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast.error("ไฟล์ขนาดใหญ่เกิน 5MB");
      return;
    }
    setSlipFile(file);
    const reader = new FileReader();
    reader.onload = ev => setSlipPreview(ev.target?.result as string);
    reader.readAsDataURL(file);
  };

  const onSubmit = async (data: FormData) => {
    let slipBase64: string | undefined;
    let slipMimeType: string | undefined;
    if (slipFile) {
      const buffer = await slipFile.arrayBuffer();
      const bytes = new Uint8Array(buffer);
      let binary = "";
      for (let i = 0; i < bytes.byteLength; i++)
        binary += String.fromCharCode(bytes[i]);
      slipBase64 = btoa(binary);
      slipMimeType = slipFile.type;
    }
    createMutation.mutate({
      ...data,
      fullName: data.rank ? `${data.rank} ${data.fullName}` : data.fullName,
      guestCount: data.guestCount || 0,
      paymentAmount: data.paymentAmount,
      paymentDate: data.paymentDate
        ? new Date(data.paymentDate).getTime()
        : undefined,
      slipBase64,
      slipMimeType,
    });
  };

  const selectedFullName = watch("fullName");
  const guestCount = watch("guestCount") || 0;
  const totalCount = 1 + guestCount;

  return (
    <div className="min-h-screen bg-background">
      {/* Geometric shapes */}
      <div
        className="geo-shape geo-blue"
        style={{ width: 300, height: 300, top: -80, right: -60 }}
      />
      <div
        className="geo-shape geo-pink"
        style={{ width: 250, height: 250, bottom: 200, left: -80 }}
      />

      {/* Header */}
      <header className="sticky top-0 z-20 border-b border-border/50 bg-white/80 backdrop-blur-sm">
        <div className="container flex items-center gap-3 py-4">
          <button
            onClick={() => navigate("/")}
            className="p-2 rounded-xl hover:bg-muted transition-colors"
          >
            <ArrowLeft size={20} />
          </button>
          <div>
            <h1 className="font-bold text-foreground text-base">
              ลงทะเบียนเข้าร่วมงาน
            </h1>
            <p className="text-xs text-muted-foreground">
              นนส.เหล่าทหารขนส่ง ประจำปี 2569
            </p>
          </div>
        </div>
        {/* Step indicator */}
        <div className="container pb-3">
          <div className="flex gap-2">
            {[1, 2, 3].map(s => (
              <div
                key={s}
                className={`h-1.5 flex-1 rounded-full transition-all duration-300 ${s <= step ? "bg-primary" : "bg-muted"}`}
              />
            ))}
          </div>
          <div className="flex justify-between mt-1.5 text-xs text-muted-foreground">
            <span className={step >= 1 ? "text-primary font-medium" : ""}>
              ข้อมูลส่วนตัว
            </span>
            <span className={step >= 2 ? "text-primary font-medium" : ""}>
              การเข้าร่วม
            </span>
            <span className={step >= 3 ? "text-primary font-medium" : ""}>
              ชำระเงิน
            </span>
          </div>
        </div>
      </header>

      <form onSubmit={handleSubmit(onSubmit as any)}>
        <div className="container py-6 max-w-lg mx-auto relative z-10">
          {/* Step 1: Personal Info */}
          {step === 1 && (
            <div className="space-y-5">
              <SectionTitle icon={<User size={18} />} title="ข้อมูลส่วนตัว" />

              <FormField label="ยศ (ทางทหาร)">
                <div className="relative">
                  <Shield
                    size={16}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground z-10"
                  />
                  <Select
                    onValueChange={v => setValue("rank", v === "-" ? "" : v)}
                  >
                    <SelectTrigger className="pl-9 rounded-xl">
                      <SelectValue placeholder="เลือกยศ (ถ้ามี)" />
                    </SelectTrigger>
                    <SelectContent className="max-h-64">
                      {MILITARY_RANKS.map(r => (
                        <SelectItem key={r} value={r}>
                          {r}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </FormField>

              <FormField
                label="ชื่อ – นามสกุล *"
                error={errors.fullName?.message}
              >
                <Input
                  {...register("fullName")}
                  list="nnskhs2131-name-suggestions"
                  placeholder="พิมพ์ชื่อ-นามสกุล หรือเลือกรายชื่อแนะนำ"
                  autoComplete="name"
                  className="rounded-xl"
                />
                <datalist id="nnskhs2131-name-suggestions">
                  {NNSKHS2131_NAMES.map(name => (
                    <option key={name} value={name} />
                  ))}
                </datalist>
                <p className="text-xs text-muted-foreground">
                  พิมพ์ชื่อเองได้ หรือเลือกจากรายชื่อแนะนำ{" "}
                  {NNSKHS2131_NAME_COUNT} รายชื่อ
                </p>
              </FormField>

              <FormField label="ชื่อเล่น">
                <Input
                  {...register("nickname")}
                  placeholder="เช่น ชาย"
                  className="rounded-xl"
                />
              </FormField>

              <FormField
                label="หมายเลขโทรศัพท์ *"
                error={errors.phone?.message}
              >
                <div className="relative">
                  <Phone
                    size={16}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                  />
                  <Input
                    {...register("phone")}
                    placeholder="08X-XXX-XXXX"
                    className="pl-9 rounded-xl"
                    type="tel"
                  />
                </div>
              </FormField>

              <FormField label="LINE ID">
                <Input
                  {...register("lineId")}
                  placeholder="@lineid หรือ ชื่อ LINE"
                  className="rounded-xl"
                />
              </FormField>

              <FormField label="จังหวัดที่อยู่ปัจจุบัน">
                <div className="relative">
                  <MapPin
                    size={16}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground z-10"
                  />
                  <Select onValueChange={v => setValue("province", v)}>
                    <SelectTrigger className="pl-9 rounded-xl">
                      <SelectValue placeholder="เลือกจังหวัด" />
                    </SelectTrigger>
                    <SelectContent className="max-h-64">
                      {PROVINCES.map(p => (
                        <SelectItem key={p} value={p}>
                          {p}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </FormField>

              <Button
                type="button"
                className="w-full rounded-xl py-6"
                onClick={async () => {
                  if (await trigger(["fullName", "phone"])) setStep(2);
                }}
              >
                ถัดไป →
              </Button>
            </div>
          )}

          {/* Step 2: Attendance Info */}
          {step === 2 && (
            <div className="space-y-5">
              <SectionTitle
                icon={<AttendanceIcon size={18} />}
                title="ข้อมูลการเข้าร่วม"
              />

              <FormField label="จำนวนผู้ติดตาม (ไม่นับตัวเอง)">
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() =>
                      setValue("guestCount", Math.max(0, guestCount - 1))
                    }
                    className="w-10 h-10 rounded-xl border border-border hover:bg-muted flex items-center justify-center text-lg font-bold transition-colors"
                  >
                    −
                  </button>
                  <span className="text-xl font-bold w-8 text-center">
                    {guestCount}
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      setValue("guestCount", Math.min(10, guestCount + 1))
                    }
                    className="w-10 h-10 rounded-xl border border-border hover:bg-muted flex items-center justify-center text-lg font-bold transition-colors"
                  >
                    +
                  </button>
                  <span className="text-sm text-muted-foreground ml-2">
                    รวมทั้งหมด{" "}
                    <strong className="text-foreground">{totalCount}</strong> คน
                  </span>
                </div>
              </FormField>

              <FormField label="ข้อความถึงเพื่อนร่วมรุ่น">
                <div className="relative">
                  <MessageSquare
                    size={16}
                    className="absolute left-3 top-3 text-muted-foreground"
                  />
                  <Textarea
                    {...register("message")}
                    placeholder="ความทรงจำ ข้อความ หรือนัดพบเพื่อนร่วมรุ่น..."
                    className="pl-9 rounded-xl min-h-[100px] resize-none"
                  />
                </div>
              </FormField>

              <div className="flex gap-3">
                <Button
                  type="button"
                  variant="outline"
                  className="flex-1 rounded-xl py-6"
                  onClick={() => setStep(1)}
                >
                  ← ย้อนกลับ
                </Button>
                <Button
                  type="button"
                  className="flex-1 rounded-xl py-6"
                  onClick={() => setStep(3)}
                >
                  ถัดไป →
                </Button>
              </div>
            </div>
          )}

          {/* Step 3: Payment */}
          {step === 3 && (
            <div className="space-y-5">
              <SectionTitle
                icon={<CreditCard size={18} />}
                title="ข้อมูลการชำระเงิน"
              />

              {/* Bank info */}
              <div className="bg-primary/5 border border-primary/20 rounded-2xl p-4">
                <p className="text-sm font-semibold text-foreground mb-2">
                  ข้อมูลบัญชีรับโอน
                </p>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">ธนาคาร</span>
                    <span className="font-medium">TTB</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">เลขบัญชี</span>
                    <span className="font-medium font-mono">473-2-80694-0</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">ชื่อบัญชี</span>
                    <span className="font-medium">นิยม สมาคม</span>
                  </div>
                  <div className="flex justify-between border-t border-primary/20 pt-2 mt-2">
                    <span className="text-muted-foreground">ค่าลงทะเบียน</span>
                    <span className="font-bold text-primary">
                      3,000 บาท / ครอบครัว
                    </span>
                  </div>
                </div>
              </div>

              <FormField label="จำนวนเงินที่โอน (บาท)">
                <Input
                  type="number"
                  placeholder="3000"
                  className="rounded-xl"
                  onChange={e =>
                    setValue("paymentAmount", Number(e.target.value))
                  }
                />
              </FormField>

              <FormField label="วันที่โอนเงิน">
                <Input
                  type="date"
                  className="rounded-xl"
                  {...register("paymentDate")}
                  max={new Date().toISOString().split("T")[0]}
                />
              </FormField>

              <FormField label="อัปโหลดสลิปโอนเงิน">
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition-all ${
                    slipPreview
                      ? "border-primary/50 bg-primary/5"
                      : "border-border hover:border-primary/40 hover:bg-muted/50"
                  }`}
                >
                  {slipPreview ? (
                    <div className="relative">
                      <img
                        src={slipPreview}
                        alt="slip"
                        className="max-h-48 mx-auto rounded-xl object-contain"
                      />
                      <button
                        type="button"
                        onClick={e => {
                          e.stopPropagation();
                          setSlipFile(null);
                          setSlipPreview(null);
                        }}
                        className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600"
                      >
                        <X size={14} />
                      </button>
                      <p className="text-xs text-primary mt-2 font-medium">
                        ✓ อัปโหลดสลิปแล้ว
                      </p>
                    </div>
                  ) : (
                    <>
                      <Upload
                        size={32}
                        className="mx-auto text-muted-foreground mb-2"
                      />
                      <p className="text-sm font-medium text-foreground">
                        คลิกเพื่ออัปโหลดสลิป
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        รองรับ JPG, PNG ขนาดไม่เกิน 5MB
                      </p>
                    </>
                  )}
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleSlipChange}
                />
              </FormField>

              {/* Summary */}
              <div className="bg-muted/50 rounded-2xl p-4 space-y-2 text-sm">
                <p className="font-semibold text-foreground mb-3">
                  สรุปการลงทะเบียน
                </p>
                <SummaryRow
                  label="ยศ / ชื่อ-สกุล"
                  value={
                    [watch("rank"), selectedFullName]
                      .filter(Boolean)
                      .join(" ") || "-"
                  }
                />
                <SummaryRow label="ชื่อเล่น" value={watch("nickname") || "-"} />
                <SummaryRow label="จำนวนรวม" value={`${totalCount} คน`} />
                <SummaryRow label="ค่าลงทะเบียน" value="3,000 บาท / ครอบครัว" />
              </div>

              <div className="flex gap-3">
                <Button
                  type="button"
                  variant="outline"
                  className="flex-1 rounded-xl py-6"
                  onClick={() => setStep(2)}
                >
                  ← ย้อนกลับ
                </Button>
                <Button
                  type="submit"
                  className="flex-1 rounded-xl py-6"
                  disabled={createMutation.isPending}
                >
                  {createMutation.isPending ? (
                    <span className="flex items-center gap-2">
                      <span className="animate-spin">⏳</span> กำลังบันทึก...
                    </span>
                  ) : (
                    <span className="flex items-center gap-2">
                      <CheckCircle2 size={18} /> ยืนยันการลงทะเบียน
                    </span>
                  )}
                </Button>
              </div>
            </div>
          )}
        </div>
      </form>
    </div>
  );
}

function AttendanceIcon({ size }: { size: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  );
}

function SectionTitle({
  icon,
  title,
}: {
  icon: React.ReactNode;
  title: string;
}) {
  return (
    <div className="flex items-center gap-2 pb-1 border-b border-border">
      <span className="text-primary">{icon}</span>
      <h2 className="font-bold text-foreground">{title}</h2>
    </div>
  );
}

function FormField({
  label,
  children,
  error,
}: {
  label: string;
  children: React.ReactNode;
  error?: string;
}) {
  return (
    <div className="space-y-1.5">
      <Label className="text-sm font-medium text-foreground">{label}</Label>
      {children}
      {error && <p className="text-xs text-destructive">{error}</p>}
    </div>
  );
}

function SummaryRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium text-foreground">{value}</span>
    </div>
  );
}
