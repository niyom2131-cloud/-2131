import { useLocation, useParams } from "wouter";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Home, Search, Share2 } from "lucide-react";

export default function ThankYou() {
  const [, navigate] = useLocation();
  const params = useParams<{ id: string }>();

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4 relative overflow-hidden">
      <div className="geo-shape geo-blue" style={{ width: 400, height: 400, top: -100, right: -100 }} />
      <div className="geo-shape geo-pink" style={{ width: 300, height: 300, bottom: -80, left: -80 }} />

      <div className="relative z-10 max-w-md w-full text-center">
        {/* Success Icon */}
        <div className="w-24 h-24 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg shadow-emerald-100">
          <CheckCircle2 size={48} className="text-emerald-600" />
        </div>

        <h1 className="text-3xl font-extrabold text-foreground mb-3">
          ลงทะเบียนสำเร็จ! 🎉
        </h1>
        <p className="text-muted-foreground mb-2 text-lg">
          ขอบคุณที่ลงทะเบียนเข้าร่วมงาน
        </p>
        <p className="text-sm text-muted-foreground mb-8">
          หมายเลขอ้างอิง: <span className="font-mono font-bold text-foreground">#{params.id}</span>
        </p>

        {/* Info Card */}
        <div className="bg-white rounded-2xl border border-border p-6 mb-6 text-left shadow-sm">
          <h3 className="font-bold text-foreground mb-4">ขั้นตอนต่อไป</h3>
          <div className="space-y-3">
            {[
              { step: "1", text: "ผู้ดูแลระบบจะตรวจสอบข้อมูลและสลิปการโอนเงิน" },
              { step: "2", text: "เมื่ออนุมัติแล้ว ท่านจะได้รับ QR Code สำหรับเข้างาน" },
              { step: "3", text: "นำ QR Code มาสแกนที่หน้างานในวันจัดงาน" },
            ].map((item) => (
              <div key={item.step} className="flex gap-3">
                <span className="w-6 h-6 rounded-full bg-primary/10 text-primary text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5">
                  {item.step}
                </span>
                <p className="text-sm text-muted-foreground">{item.text}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div className="space-y-3">
          <Button
            className="w-full rounded-xl py-5"
            onClick={() => navigate("/check-status")}
          >
            <Search size={16} className="mr-2" />
            ตรวจสอบสถานะการลงทะเบียน
          </Button>
          <Button
            variant="outline"
            className="w-full rounded-xl py-5"
            onClick={() => navigate("/")}
          >
            <Home size={16} className="mr-2" />
            กลับหน้าหลัก
          </Button>
          <button
            className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mx-auto transition-colors"
            onClick={() => {
              if (navigator.share) {
                navigator.share({ title: "งานเลี้ยงรุ่น นนส.เหล่าทหารขนส่ง 2569", url: window.location.origin });
              }
            }}
          >
            <Share2 size={14} />
            แชร์ให้เพื่อนร่วมรุ่น
          </button>
        </div>
      </div>
    </div>
  );
}
