import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Download, Share2, QrCode, Shield, CheckCircle2 } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import QRCode from "qrcode";

export default function MyQrCode() {
  const [location, navigate] = useLocation();
  const params = new URLSearchParams(location.split("?")[1] || "");
  const phone = params.get("phone") || "";
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const [qrReady, setQrReady] = useState(false);

  const { data, isLoading, error } = trpc.registration.getMyQr.useQuery(
    { phone },
    { enabled: !!phone }
  );

  useEffect(() => {
    if (data?.qrToken && canvasRef.current) {
      QRCode.toCanvas(canvasRef.current, data.qrToken, {
        width: 240,
        margin: 2,
        color: { dark: "#0f2d5e", light: "#ffffff" },
        errorCorrectionLevel: "H",
      }).then(() => setQrReady(true));
    }
  }, [data?.qrToken]);

  const handleDownload = async () => {
    const canvas = canvasRef.current;
    if (!canvas || !data) return;

    // สร้าง canvas ใหม่สำหรับ export พร้อมข้อมูล
    const exportCanvas = document.createElement("canvas");
    const scale = 2;
    exportCanvas.width = 400 * scale;
    exportCanvas.height = 560 * scale;
    const ctx = exportCanvas.getContext("2d")!;
    ctx.scale(scale, scale);

    // พื้นหลัง gradient
    const grad = ctx.createLinearGradient(0, 0, 0, 560);
    grad.addColorStop(0, "#0f2d5e");
    grad.addColorStop(1, "#1a4a8a");
    ctx.fillStyle = grad;
    ctx.roundRect(0, 0, 400, 560, 24);
    ctx.fill();

    // ส่วนหัว
    ctx.fillStyle = "rgba(255,255,255,0.1)";
    ctx.roundRect(20, 20, 360, 80, 16);
    ctx.fill();

    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 20px Sarabun, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("🎖️ งานเลี้ยงรุ่น นนส.เหล่าทหารขนส่ง", 200, 52);
    ctx.font = "14px Sarabun, sans-serif";
    ctx.fillStyle = "rgba(255,255,255,0.75)";
    ctx.fillText("ประจำปี 2569 | เสาร์ที่ 24 ตุลาคม 2569", 200, 80);

    // กรอบ QR Code
    ctx.fillStyle = "#ffffff";
    ctx.roundRect(80, 120, 240, 260, 20);
    ctx.fill();

    // วาด QR Code
    ctx.drawImage(canvas, 90, 130, 220, 220);

    // Token text
    ctx.fillStyle = "#64748b";
    ctx.font = "10px monospace";
    ctx.textAlign = "center";
    ctx.fillText(data.qrToken, 200, 368);

    // ชื่อ
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 22px Sarabun, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(data.fullName, 200, 420);

    if (data.nickname && data.nickname.length > 0) {
      ctx.fillStyle = "rgba(255,255,255,0.7)";
      ctx.font = "16px Sarabun, sans-serif";
      ctx.fillText(`(${data.nickname})`, 200, 445);
    }

    // Badge อนุมัติแล้ว
    ctx.fillStyle = "rgba(16,185,129,0.2)";
    ctx.roundRect(120, 465, 160, 36, 18);
    ctx.fill();
    ctx.strokeStyle = "rgba(16,185,129,0.5)";
    ctx.lineWidth = 1;
    ctx.roundRect(120, 465, 160, 36, 18);
    ctx.stroke();
    ctx.fillStyle = "#6ee7b7";
    ctx.font = "bold 14px Sarabun, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("✅ ได้รับการอนุมัติแล้ว", 200, 488);

    // Footer
    ctx.fillStyle = "rgba(255,255,255,0.4)";
    ctx.font = "11px Sarabun, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("กรุณาแสดง QR Code นี้ที่จุดลงทะเบียนหน้างาน", 200, 535);

    const link = document.createElement("a");
    link.download = `QR-${(data.fullName || "reunion").replace(/\s+/g, "-")}.png`;
    link.href = exportCanvas.toDataURL("image/png");
    link.click();
  };

  const handleShare = async () => {
    if (!data) return;
    if (navigator.share) {
      try {
        await navigator.share({
          title: "QR Code เข้างานเลี้ยงรุ่น นนส.",
          text: `${data.fullName} — QR Token: ${data.qrToken}`,
        });
      } catch {
        // user cancelled
      }
    } else {
      navigator.clipboard.writeText(data.qrToken);
      alert("คัดลอก QR Token แล้ว: " + data.qrToken);
    }
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <div className="geo-shape geo-blue" style={{ width: 350, height: 350, top: -80, right: -80 }} />
      <div className="geo-shape geo-pink" style={{ width: 280, height: 280, bottom: 100, left: -80 }} />

      <header className="sticky top-0 z-20 border-b border-border/50 bg-white/80 backdrop-blur-sm">
        <div className="container flex items-center gap-3 py-4">
          <button
            onClick={() => navigate("/check-status")}
            className="p-2 rounded-xl hover:bg-muted transition-colors"
          >
            <ArrowLeft size={20} />
          </button>
          <div>
            <h1 className="font-bold text-foreground">QR Code เข้างาน</h1>
            <p className="text-xs text-muted-foreground">สำหรับสแกนที่จุดลงทะเบียนหน้างาน</p>
          </div>
        </div>
      </header>

      <div className="container py-8 max-w-sm mx-auto relative z-10">
        {isLoading && (
          <div className="text-center py-16">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4 animate-pulse">
              <QrCode size={28} className="text-primary" />
            </div>
            <p className="text-muted-foreground font-medium">กำลังโหลด QR Code...</p>
          </div>
        )}

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-2xl p-6 text-red-800 text-center">
            <div className="text-4xl mb-3">🚫</div>
            <p className="font-bold mb-1">ไม่สามารถแสดง QR Code ได้</p>
            <p className="text-sm">{error.message}</p>
            <Button variant="outline" className="mt-4 rounded-xl" onClick={() => navigate("/check-status")}>
              กลับไปตรวจสอบสถานะ
            </Button>
          </div>
        )}

        {data && (
          <div className="space-y-5">
            {/* QR Card */}
            <div
              ref={cardRef}
              className="rounded-3xl overflow-hidden shadow-xl"
              style={{ background: "linear-gradient(160deg, #0f2d5e 0%, #1a4a8a 100%)" }}
            >
              {/* Header */}
              <div className="px-6 pt-6 pb-4 text-center border-b border-white/10">
                <div className="flex items-center justify-center gap-2 mb-1">
                  <Shield size={16} className="text-blue-300" />
                  <span className="text-blue-200 text-xs font-medium tracking-wide uppercase">
                    งานเลี้ยงรุ่น นนส.เหล่าทหารขนส่ง
                  </span>
                </div>
                <p className="text-white/60 text-xs">ประจำปี 2569 | เสาร์ที่ 24 ตุลาคม 2569</p>
              </div>

              {/* QR Code */}
              <div className="flex flex-col items-center py-6 px-6">
                <div className="bg-white rounded-2xl p-4 shadow-lg mb-2">
                  <canvas ref={canvasRef} className="rounded-xl block" />
                </div>
                <p className="text-white/40 text-[10px] font-mono mt-2 break-all text-center px-2">
                  {data.qrToken}
                </p>
              </div>

              {/* Name */}
              <div className="px-6 pb-4 text-center border-t border-white/10 pt-4">
                <p className="text-white font-extrabold text-xl leading-tight">{data.fullName}</p>
                {data.nickname && data.nickname.length > 0 && (
                  <p className="text-white/60 text-sm mt-0.5">({data.nickname})</p>
                )}
              </div>

              {/* Status badge */}
              <div className="px-6 pb-6">
                <div className="bg-emerald-500/20 border border-emerald-400/30 rounded-2xl py-3 px-4 flex items-center justify-center gap-2">
                  <CheckCircle2 size={16} className="text-emerald-300" />
                  <span className="text-emerald-200 text-sm font-semibold">ได้รับการอนุมัติแล้ว</span>
                </div>
              </div>
            </div>

            {/* Instruction */}
            <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 text-sm text-blue-800">
              <p className="font-semibold mb-1">📋 วิธีใช้งาน</p>
              <p>กรุณาแสดง QR Code นี้แก่เจ้าหน้าที่ที่จุดลงทะเบียนหน้างาน เพื่อยืนยันการเข้าร่วมงาน</p>
            </div>

            {/* Action buttons */}
            <div className="flex gap-3">
              <Button
                variant="outline"
                className="flex-1 rounded-xl py-5 border-2"
                onClick={handleDownload}
                disabled={!qrReady}
              >
                <Download size={16} className="mr-2" />
                บันทึกรูป
              </Button>
              <Button
                className="flex-1 rounded-xl py-5"
                onClick={handleShare}
              >
                <Share2 size={16} className="mr-2" />
                แชร์
              </Button>
            </div>

            <Button
              variant="ghost"
              className="w-full rounded-xl text-muted-foreground"
              onClick={() => navigate("/check-status")}
            >
              <ArrowLeft size={16} className="mr-2" />
              กลับหน้าตรวจสอบสถานะ
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
