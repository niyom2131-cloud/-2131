import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { Calendar, MapPin, Clock, Users, ChevronRight, Shield } from "lucide-react";

export default function Home() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Geometric background shapes */}
      <div className="geo-shape geo-blue" style={{ width: 500, height: 500, top: -150, right: -100 }} />
      <div className="geo-shape geo-pink" style={{ width: 400, height: 400, bottom: 100, left: -120 }} />
      <div className="geo-shape geo-blue" style={{ width: 200, height: 200, bottom: 300, right: 50 }} />

      {/* Header */}
      <header className="relative z-10 border-b border-border/50 bg-white/70 backdrop-blur-sm">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center text-white font-bold text-sm shadow-md">
              นนส.
            </div>
            <div>
              <p className="font-bold text-foreground text-sm leading-tight">เหล่าทหารขนส่ง</p>
              <p className="text-xs text-muted-foreground">ระบบลงทะเบียน 2569</p>
            </div>
          </div>
          <button
            onClick={() => navigate("/admin")}
            className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors px-3 py-1.5 rounded-lg hover:bg-muted"
          >
            <Shield size={14} />
            ผู้ดูแล
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <main className="relative z-10">
        <section className="container py-16 md:py-24">
          <div className="max-w-2xl mx-auto text-center">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 bg-primary/10 text-primary rounded-full px-4 py-1.5 text-sm font-medium mb-6">
              <span>🎖️</span>
              <span>งานคืนสู่เหย้า ประจำปี 2569</span>
            </div>

            {/* Title */}
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-foreground leading-tight mb-4">
              งานเลี้ยงรุ่น
              <br />
              <span className="text-primary">นนส.</span>
              <span className="text-foreground"> เหล่าทหารขนส่ง</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground font-light mb-10 leading-relaxed">
              ร่วมรำลึกความทรงจำ พบปะเพื่อนเก่า<br className="hidden md:block" />
              สร้างความทรงจำใหม่ไปด้วยกัน
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 justify-center mb-16">
              <Button
                size="lg"
                className="text-base px-8 py-6 rounded-2xl shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 transition-all duration-200"
                onClick={() => navigate("/register")}
              >
                ลงทะเบียนเข้าร่วมงาน
                <ChevronRight size={18} className="ml-1" />
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="text-base px-8 py-6 rounded-2xl border-2 hover:bg-muted/50 transition-all duration-200"
                onClick={() => navigate("/check-status")}
              >
                ตรวจสอบสถานะ
              </Button>
            </div>

            {/* Event Info Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <EventCard
                icon={<Calendar className="text-primary" size={22} />}
                label="วันที่จัดงาน"
                value="เสาร์ที่ 24 ตุลาคม 2569"
              />
              <EventCard
                icon={<Clock className="text-pink-500" size={22} />}
                label="เวลา"
                value="14:00 – 22:00 น."
              />
              <EventCard
                icon={<MapPin className="text-emerald-500" size={22} />}
                label="สถานที่"
                value="ศูนย์ส่งเสริมคุณภาพชีวิตข้าราชการกองทัพเรือ"
              />
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="bg-white/60 backdrop-blur-sm border-y border-border/50 py-16">
          <div className="container">
            <h2 className="text-2xl md:text-3xl font-bold text-center text-foreground mb-10">
              ขั้นตอนการลงทะเบียน
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
              {[
                { step: "01", title: "กรอกข้อมูล", desc: "กรอกข้อมูลส่วนตัวและข้อมูลการเข้าร่วม", color: "bg-primary/10 text-primary" },
                { step: "02", title: "ชำระเงิน", desc: "โอนเงินและอัปโหลดสลิปการโอน", color: "bg-pink-100 text-pink-600" },
                { step: "03", title: "รอตรวจสอบ", desc: "ผู้ดูแลตรวจสอบและอนุมัติภายใน 24 ชม.", color: "bg-amber-100 text-amber-600" },
                { step: "04", title: "รับ QR Code", desc: "รับ QR Code สำหรับเข้างานในวันจริง", color: "bg-emerald-100 text-emerald-600" },
              ].map((item) => (
                <div key={item.step} className="text-center">
                  <div className={`w-14 h-14 rounded-2xl ${item.color} flex items-center justify-center text-xl font-bold mx-auto mb-3`}>
                    {item.step}
                  </div>
                  <h3 className="font-semibold text-foreground mb-1">{item.title}</h3>
                  <p className="text-sm text-muted-foreground">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="container py-16">
          <div className="max-w-2xl mx-auto">
            <div className="bg-white rounded-3xl border border-border shadow-sm p-8 text-center">
              <div className="flex items-center justify-center gap-2 mb-4">
                <Users className="text-primary" size={24} />
                <h3 className="text-xl font-bold text-foreground">ร่วมงานกับเพื่อนร่วมรุ่น</h3>
              </div>
              <p className="text-muted-foreground mb-6">
                ลงทะเบียนวันนี้เพื่อไม่พลาดโอกาสพบปะเพื่อนเก่า<br />
                พร้อมรับเสื้อที่ระลึกสุดพิเศษ
              </p>
              <Button
                onClick={() => navigate("/register")}
                className="rounded-xl px-8"
              >
                ลงทะเบียนเลย
              </Button>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-border/50 py-6 text-center text-sm text-muted-foreground">
        <p>© 2569 งานเลี้ยงรุ่น นนส.เหล่าทหารขนส่ง · พัฒนาโดยระบบลงทะเบียนออนไลน์</p>
      </footer>
    </div>
  );
}

function EventCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="bg-white rounded-2xl border border-border p-5 text-center shadow-sm hover:shadow-md transition-shadow">
      <div className="flex justify-center mb-2">{icon}</div>
      <p className="text-xs text-muted-foreground mb-1">{label}</p>
      <p className="text-sm font-semibold text-foreground">{value}</p>
    </div>
  );
}
