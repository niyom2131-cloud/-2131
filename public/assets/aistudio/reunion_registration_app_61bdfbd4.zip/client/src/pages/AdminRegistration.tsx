import { useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  NNSKHS2131_NAME_COUNT,
  NNSKHS2131_NAMES,
} from "@/data/nnskhs2131Names";
import {
  ArrowLeft,
  CreditCard,
  MapPin,
  Phone,
  Save,
  Shield,
  Upload,
  UserPlus,
  X,
} from "lucide-react";
import { toast } from "sonner";

const PROVINCES = [
  "กรุงเทพมหานคร",
  "กระบี่",
  "กาญจนบุรี",
  "กาฬสินธุ์",
  "กำแพงเพชร",
  "ขอนแก่น",
  "จันทบุรี",
  "ฉะเชิงเทรา",
  "ชลบุรี",
  "ชัยนาท",
  "ชัยภูมิ",
  "ชุมพร",
  "เชียงราย",
  "เชียงใหม่",
  "ตรัง",
  "ตราด",
  "ตาก",
  "นครนายก",
  "นครปฐม",
  "นครพนม",
  "นครราชสีมา",
  "นครศรีธรรมราช",
  "นครสวรรค์",
  "นนทบุรี",
  "นราธิวาส",
  "น่าน",
  "บึงกาฬ",
  "บุรีรัมย์",
  "ปทุมธานี",
  "ประจวบคีรีขันธ์",
  "ปราจีนบุรี",
  "ปัตตานี",
  "พระนครศรีอยุธยา",
  "พะเยา",
  "พังงา",
  "พัทลุง",
  "พิจิตร",
  "พิษณุโลก",
  "เพชรบุรี",
  "เพชรบูรณ์",
  "แพร่",
  "ภูเก็ต",
  "มหาสารคาม",
  "มุกดาหาร",
  "แม่ฮ่องสอน",
  "ยโสธร",
  "ยะลา",
  "ร้อยเอ็ด",
  "ระนอง",
  "ระยอง",
  "ราชบุรี",
  "ลพบุรี",
  "ลำปาง",
  "ลำพูน",
  "เลย",
  "ศรีสะเกษ",
  "สกลนคร",
  "สงขลา",
  "สตูล",
  "สมุทรปราการ",
  "สมุทรสงคราม",
  "สมุทรสาคร",
  "สระแก้ว",
  "สระบุรี",
  "สิงห์บุรี",
  "สุโขทัย",
  "สุพรรณบุรี",
  "สุราษฎร์ธานี",
  "สุรินทร์",
  "หนองคาย",
  "หนองบัวลำภู",
  "อ่างทอง",
  "อำนาจเจริญ",
  "อุดรธานี",
  "อุตรดิตถ์",
  "อุทัยธานี",
  "อุบลราชธานี",
];

const MILITARY_RANKS = [
  "พล.อ.",
  "พล.อ.อ.",
  "พล.ร.อ.",
  "พล.ท.",
  "พล.อ.ท.",
  "พล.ร.ท.",
  "พล.ต.",
  "พล.อ.ต.",
  "พล.ร.ต.",
  "พ.อ.",
  "น.อ.",
  "น.อ.(พิเศษ)",
  "พ.ท.",
  "น.ท.",
  "พ.ต.",
  "น.ต.",
  "ร.อ.",
  "ร.ต.อ.",
  "จ.อ.",
  "ร.ท.",
  "ร.ต.ท.",
  "จ.ท.",
  "ร.ต.",
  "ร.ต.ต.",
  "จ.ต.",
  "จ.ส.อ.",
  "จ.ส.ท.",
  "จ.ส.ต.",
  "ส.อ.",
  "ส.ท.",
  "ส.ต.",
  "พลฯ",
  "พลทหาร",
  "นาย",
  "นาง",
  "นางสาว",
  "-",
];

const schema = z.object({
  rank: z.string().optional(),
  fullName: z.string().min(2, "กรุณากรอกชื่อ-นามสกุล"),
  nickname: z.string().optional(),
  phone: z.string().min(9, "กรุณากรอกเบอร์โทรศัพท์ที่ถูกต้อง"),
  lineId: z.string().optional(),
  province: z.string().optional(),
  guestCount: z.number().int().min(0).max(10),
  message: z.string().optional(),
  paymentAmount: z.number().int().min(0).optional(),
  paymentDate: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

export default function AdminRegistration() {
  const [, navigate] = useLocation();
  const { user, loading } = useAuth();
  const [slipFile, setSlipFile] = useState<File | null>(null);
  const [slipPreview, setSlipPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(schema) as any,
    defaultValues: { rank: "", guestCount: 0 },
  });

  useEffect(() => {
    if (!loading && (!user || user.role !== "admin")) navigate("/admin");
  }, [loading, user, navigate]);

  const createMutation = trpc.admin.createRegistration.useMutation({
    onSuccess: data => {
      toast.success("บันทึกการลงทะเบียนแทนเรียบร้อย");
      navigate(`/admin/participants/${data.id}`);
    },
    onError: error => toast.error(`เกิดข้อผิดพลาด: ${error.message}`),
  });

  const guestCount = watch("guestCount") || 0;

  const handleSlipChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast.error("ไฟล์ขนาดใหญ่เกิน 5MB");
      return;
    }
    setSlipFile(file);
    const reader = new FileReader();
    reader.onload = loadEvent =>
      setSlipPreview(loadEvent.target?.result as string);
    reader.readAsDataURL(file);
  };

  const onSubmit = async (data: FormData) => {
    let slipBase64: string | undefined;
    let slipMimeType: string | undefined;
    if (slipFile) {
      const bytes = new Uint8Array(await slipFile.arrayBuffer());
      let binary = "";
      for (let index = 0; index < bytes.byteLength; index += 1)
        binary += String.fromCharCode(bytes[index]);
      slipBase64 = btoa(binary);
      slipMimeType = slipFile.type;
    }

    createMutation.mutate({
      fullName: data.rank ? `${data.rank} ${data.fullName}` : data.fullName,
      nickname: data.nickname || undefined,
      phone: data.phone,
      lineId: data.lineId || undefined,
      province: data.province || undefined,
      guestCount: data.guestCount,
      message: data.message || undefined,
      paymentAmount: data.paymentAmount,
      paymentDate: data.paymentDate
        ? new Date(data.paymentDate).getTime()
        : undefined,
      slipBase64,
      slipMimeType,
    });
  };

  if (loading || !user) return <LoadingScreen />;
  if (user.role !== "admin") return null;

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-20 border-b border-border/50 bg-white/90 backdrop-blur-sm">
        <div className="container flex items-center gap-3 py-3">
          <button
            type="button"
            onClick={() => navigate("/admin/dashboard")}
            className="p-2 rounded-xl hover:bg-muted transition-colors"
            aria-label="กลับหน้า Dashboard"
          >
            <ArrowLeft size={20} />
          </button>
          <div>
            <h1 className="font-bold text-foreground">
              ลงทะเบียนแทนผู้เข้าร่วม
            </h1>
            <p className="text-xs text-muted-foreground">
              สำหรับผู้ดูแลระบบเท่านั้น
            </p>
          </div>
        </div>
      </header>

      <main className="container max-w-2xl py-6">
        <div className="mb-5 rounded-2xl border border-primary/20 bg-primary/5 p-4">
          <div className="flex gap-3">
            <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground">
              <UserPlus size={19} />
            </div>
            <div>
              <h2 className="font-semibold text-foreground">
                บันทึกแทนผู้เข้าร่วม
              </h2>
              <p className="mt-0.5 text-sm text-muted-foreground">
                รายการที่เพิ่มจากหน้านี้จะอยู่ในสถานะรอตรวจสอบเช่นเดียวกับการลงทะเบียนปกติ
              </p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
          <Section title="ข้อมูลส่วนตัว" icon={<Shield size={17} />}>
            <FormField label="ยศ (ทางทหาร)">
              <Select
                onValueChange={value =>
                  setValue("rank", value === "-" ? "" : value)
                }
              >
                <SelectTrigger className="rounded-xl">
                  <SelectValue placeholder="เลือกยศ (ถ้ามี)" />
                </SelectTrigger>
                <SelectContent className="max-h-64">
                  {MILITARY_RANKS.map(rank => (
                    <SelectItem key={rank} value={rank}>
                      {rank}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </FormField>

            <FormField
              label="ชื่อ – นามสกุล *"
              error={errors.fullName?.message}
            >
              <Input
                {...register("fullName")}
                list="admin-nnskhs2131-name-suggestions"
                placeholder="พิมพ์ชื่อ-นามสกุล หรือเลือกรายชื่อแนะนำ"
                autoComplete="name"
                className="rounded-xl"
              />
              <datalist id="admin-nnskhs2131-name-suggestions">
                {NNSKHS2131_NAMES.map(name => (
                  <option key={name} value={name} />
                ))}
              </datalist>
              <p className="text-xs text-muted-foreground">
                พิมพ์ชื่อเองได้ หรือเลือกจากรายชื่อแนะนำ {NNSKHS2131_NAME_COUNT}{" "}
                รายชื่อ
              </p>
            </FormField>

            <div className="grid gap-4 sm:grid-cols-2">
              <FormField label="ชื่อเล่น">
                <Input
                  {...register("nickname")}
                  className="rounded-xl"
                  placeholder="เช่น ชาย"
                />
              </FormField>
              <FormField
                label="หมายเลขโทรศัพท์ *"
                error={errors.phone?.message}
              >
                <div className="relative">
                  <Phone
                    size={16}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                  />
                  <Input
                    {...register("phone")}
                    type="tel"
                    className="rounded-xl pl-9"
                    placeholder="08X-XXX-XXXX"
                  />
                </div>
              </FormField>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <FormField label="LINE ID">
                <Input
                  {...register("lineId")}
                  className="rounded-xl"
                  placeholder="@lineid หรือ ชื่อ LINE"
                />
              </FormField>
              <FormField label="จังหวัดที่อยู่ปัจจุบัน">
                <Select onValueChange={value => setValue("province", value)}>
                  <SelectTrigger className="rounded-xl">
                    <MapPin size={15} className="mr-1 text-muted-foreground" />
                    <SelectValue placeholder="เลือกจังหวัด" />
                  </SelectTrigger>
                  <SelectContent className="max-h-64">
                    {PROVINCES.map(province => (
                      <SelectItem key={province} value={province}>
                        {province}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </FormField>
            </div>
          </Section>

          <Section title="ข้อมูลการเข้าร่วม" icon={<UserPlus size={17} />}>
            <FormField label="จำนวนผู้ติดตาม (ไม่นับตัวเอง)">
              <div className="flex items-center gap-3">
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  className="rounded-xl"
                  onClick={() =>
                    setValue("guestCount", Math.max(0, guestCount - 1))
                  }
                >
                  −
                </Button>
                <span className="w-8 text-center text-lg font-bold">
                  {guestCount}
                </span>
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  className="rounded-xl"
                  onClick={() =>
                    setValue("guestCount", Math.min(10, guestCount + 1))
                  }
                >
                  +
                </Button>
                <span className="text-sm text-muted-foreground">
                  รวมทั้งหมด{" "}
                  <strong className="text-foreground">{guestCount + 1}</strong>{" "}
                  คน
                </span>
              </div>
            </FormField>
            <FormField label="ข้อความถึงเพื่อนร่วมรุ่น">
              <Textarea
                {...register("message")}
                className="min-h-24 rounded-xl resize-none"
                placeholder="ความทรงจำ ข้อความ หรือนัดพบเพื่อนร่วมรุ่น..."
              />
            </FormField>
          </Section>

          <Section title="ข้อมูลการชำระเงิน" icon={<CreditCard size={17} />}>
            <div className="rounded-xl border border-primary/20 bg-primary/5 p-3 text-sm text-muted-foreground">
              ค่าลงทะเบียน{" "}
              <strong className="text-primary">3,000 บาท / ครอบครัว</strong> ·
              ธนาคาร TTB 473-2-80694-0 (นิยม สมาคม)
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <FormField label="จำนวนเงินที่โอน (บาท)">
                <Input
                  type="number"
                  className="rounded-xl"
                  placeholder="3000"
                  onChange={event =>
                    setValue(
                      "paymentAmount",
                      event.target.value
                        ? Number(event.target.value)
                        : undefined
                    )
                  }
                />
              </FormField>
              <FormField label="วันที่โอนเงิน">
                <Input
                  type="date"
                  className="rounded-xl"
                  {...register("paymentDate")}
                  max={new Date().toISOString().split("T")[0]}
                />
              </FormField>
            </div>
            <FormField label="อัปโหลดสลิปโอนเงิน">
              <div
                onClick={() => fileInputRef.current?.click()}
                className={`cursor-pointer rounded-2xl border-2 border-dashed p-5 text-center transition-colors ${slipPreview ? "border-primary/50 bg-primary/5" : "border-border hover:border-primary/40 hover:bg-muted/50"}`}
              >
                {slipPreview ? (
                  <div className="relative">
                    <img
                      src={slipPreview}
                      alt="ตัวอย่างสลิป"
                      className="mx-auto max-h-48 rounded-xl object-contain"
                    />
                    <button
                      type="button"
                      onClick={event => {
                        event.stopPropagation();
                        setSlipFile(null);
                        setSlipPreview(null);
                      }}
                      className="absolute right-1 top-1 rounded-full bg-red-600 p-1 text-white"
                      aria-label="ลบสลิป"
                    >
                      <X size={14} />
                    </button>
                    <p className="mt-2 text-xs font-medium text-primary">
                      อัปโหลดสลิปแล้ว
                    </p>
                  </div>
                ) : (
                  <>
                    <Upload
                      size={28}
                      className="mx-auto mb-2 text-muted-foreground"
                    />
                    <p className="text-sm font-medium">คลิกเพื่ออัปโหลดสลิป</p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      รองรับ JPG, PNG ขนาดไม่เกิน 5MB
                    </p>
                  </>
                )}
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleSlipChange}
              />
            </FormField>
          </Section>

          <div className="flex gap-3 pb-6">
            <Button
              type="button"
              variant="outline"
              className="flex-1 rounded-xl py-6"
              onClick={() => navigate("/admin/participants")}
            >
              ยกเลิก
            </Button>
            <Button
              type="submit"
              className="flex-1 rounded-xl py-6"
              disabled={createMutation.isPending}
            >
              <Save size={17} className="mr-2" />
              {createMutation.isPending
                ? "กำลังบันทึก..."
                : "บันทึกการลงทะเบียน"}
            </Button>
          </div>
        </form>
      </main>
    </div>
  );
}

function Section({
  title,
  icon,
  children,
}: {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <section className="space-y-4 rounded-2xl border border-border bg-white p-4 shadow-sm">
      <div className="flex items-center gap-2 border-b border-border pb-3">
        <span className="text-primary">{icon}</span>
        <h2 className="font-semibold text-foreground">{title}</h2>
      </div>
      {children}
    </section>
  );
}

function FormField({
  label,
  error,
  children,
}: {
  label: string;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <Label className="text-sm font-medium">{label}</Label>
      {children}
      {error && <p className="text-xs text-destructive">{error}</p>}
    </div>
  );
}

function LoadingScreen() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background">
      <div className="text-3xl animate-spin">⏳</div>
    </div>
  );
}
