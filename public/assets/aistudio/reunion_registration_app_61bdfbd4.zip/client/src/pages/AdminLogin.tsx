import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import { Shield, LogIn, ArrowLeft } from "lucide-react";

export default function AdminLogin() {
  const [, navigate] = useLocation();
  const { user, loading } = useAuth();

  useEffect(() => {
    if (!loading && user?.role === "admin") {
      navigate("/admin/dashboard");
    }
  }, [user, loading, navigate]);

  // ถ้า loading แต่ยังไม่มี user ให้แสดงหน้า login ได้เลย
  // ถ้า loading และมี user ให้รอ redirect

  if (user && user.role !== "admin") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="max-w-sm w-full text-center">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Shield size={28} className="text-red-600" />
          </div>
          <h2 className="text-xl font-bold text-foreground mb-2">ไม่มีสิทธิ์เข้าถึง</h2>
          <p className="text-muted-foreground text-sm mb-6">บัญชีนี้ไม่ได้รับสิทธิ์ผู้ดูแลระบบ</p>
          <Button variant="outline" onClick={() => navigate("/")} className="rounded-xl">
            <ArrowLeft size={16} className="mr-2" />
            กลับหน้าหลัก
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4 relative overflow-hidden">
      <div className="geo-shape geo-blue" style={{ width: 400, height: 400, top: -100, right: -100 }} />
      <div className="geo-shape geo-pink" style={{ width: 300, height: 300, bottom: -80, left: -80 }} />

      <div className="relative z-10 max-w-sm w-full">
        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-8 transition-colors"
        >
          <ArrowLeft size={16} />
          กลับหน้าหลัก
        </button>

        <div className="bg-white rounded-3xl border border-border p-8 shadow-sm text-center">
          <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Shield size={28} className="text-primary" />
          </div>
          <h1 className="text-2xl font-extrabold text-foreground mb-2">เข้าสู่ระบบผู้ดูแล</h1>
          <p className="text-muted-foreground text-sm mb-8">
            ระบบจัดการงานเลี้ยงรุ่น<br />นนส.เหล่าทหารขนส่ง 2569
          </p>

          <Button
            className="w-full rounded-xl py-5 text-base"
            onClick={() => window.location.href = getLoginUrl()}
          >
            <LogIn size={18} className="mr-2" />
            เข้าสู่ระบบด้วย Manus
          </Button>

          <p className="text-xs text-muted-foreground mt-4">
            เฉพาะผู้ดูแลระบบที่ได้รับสิทธิ์เท่านั้น
          </p>
        </div>
      </div>
    </div>
  );
}
