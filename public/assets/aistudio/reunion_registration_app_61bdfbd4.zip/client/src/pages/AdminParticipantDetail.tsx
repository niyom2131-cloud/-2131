import { useEffect, useRef, useState } from "react";
import { useLocation, useParams } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import {
  ArrowLeft,
  Calendar,
  CheckCircle2,
  CreditCard,
  Edit2,
  ExternalLink,
  MapPin,
  MessageSquare,
  Phone,
  QrCode,
  Save,
  Trash2,
  Upload,
  Users,
  X,
  XCircle,
} from "lucide-react";

type EditForm = {
  fullName: string;
  nickname: string;
  phone: string;
  lineId: string;
  province: string;
  guestCount: string;
  message: string;
  paymentAmount: string;
  paymentDate: string;
  adminNote: string;
};

function formatDateForInput(value: number | null) {
  return value ? new Date(value).toISOString().slice(0, 10) : "";
}

export default function AdminParticipantDetail() {
  const [, navigate] = useLocation();
  const params = useParams<{ id: string }>();
  const { user, loading } = useAuth();
  const utils = trpc.useUtils();
  const [isEditing, setIsEditing] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [replacementSlipFile, setReplacementSlipFile] = useState<File | null>(
    null
  );
  const [replacementSlipPreview, setReplacementSlipPreview] = useState<
    string | null
  >(null);
  const replacementSlipInputRef = useRef<HTMLInputElement>(null);
  const [form, setForm] = useState<EditForm>({
    fullName: "",
    nickname: "",
    phone: "",
    lineId: "",
    province: "",
    guestCount: "0",
    message: "",
    paymentAmount: "",
    paymentDate: "",
    adminNote: "",
  });

  useEffect(() => {
    if (!loading && (!user || user.role !== "admin")) navigate("/admin");
  }, [user, loading, navigate]);

  const { data: p, isLoading } = trpc.admin.getById.useQuery(
    { id: Number(params.id) },
    { enabled: !!user && user.role === "admin" && !!params.id }
  );

  useEffect(() => {
    if (!p) return;
    setForm({
      fullName: p.fullName,
      nickname: p.nickname || "",
      phone: p.phone,
      lineId: p.lineId || "",
      province: p.province || "",
      guestCount: String(p.guestCount),
      message: p.message || "",
      paymentAmount: p.paymentAmount == null ? "" : String(p.paymentAmount),
      paymentDate: formatDateForInput(p.paymentDate),
      adminNote: p.adminNote || "",
    });
  }, [p]);

  const approveMutation = trpc.admin.approve.useMutation({
    onSuccess: () => {
      toast.success("อนุมัติสำเร็จ! QR Code ถูกสร้างแล้ว");
      utils.admin.getById.invalidate();
      utils.admin.list.invalidate();
      utils.admin.stats.invalidate();
    },
    onError: error => toast.error(`เกิดข้อผิดพลาด: ${error.message}`),
  });

  const rejectMutation = trpc.admin.reject.useMutation({
    onSuccess: () => {
      toast.success("ปฏิเสธการลงทะเบียนแล้ว");
      utils.admin.getById.invalidate();
      utils.admin.list.invalidate();
      utils.admin.stats.invalidate();
    },
    onError: error => toast.error(`เกิดข้อผิดพลาด: ${error.message}`),
  });

  const updateMutation = trpc.admin.update.useMutation({
    onSuccess: () => {
      toast.success("บันทึกข้อมูลผู้ลงทะเบียนแล้ว");
      setIsEditing(false);
      utils.admin.getById.invalidate();
      utils.admin.list.invalidate();
      utils.admin.stats.invalidate();
    },
    onError: error => toast.error(`เกิดข้อผิดพลาด: ${error.message}`),
  });

  const deleteMutation = trpc.admin.delete.useMutation({
    onSuccess: () => {
      toast.success("ลบข้อมูลผู้ลงทะเบียนแล้ว");
      utils.admin.list.invalidate();
      utils.admin.stats.invalidate();
      navigate("/admin/participants");
    },
    onError: error => toast.error(`เกิดข้อผิดพลาด: ${error.message}`),
  });

  const setField = (field: keyof EditForm, value: string) =>
    setForm(current => ({ ...current, [field]: value }));

  const cancelEdit = () => {
    if (p) {
      setForm({
        fullName: p.fullName,
        nickname: p.nickname || "",
        phone: p.phone,
        lineId: p.lineId || "",
        province: p.province || "",
        guestCount: String(p.guestCount),
        message: p.message || "",
        paymentAmount: p.paymentAmount == null ? "" : String(p.paymentAmount),
        paymentDate: formatDateForInput(p.paymentDate),
        adminNote: p.adminNote || "",
      });
    }
    setReplacementSlipFile(null);
    setReplacementSlipPreview(null);
    setIsEditing(false);
  };

  const handleReplacementSlip = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast.error("ไฟล์ขนาดใหญ่เกิน 5MB");
      return;
    }
    setReplacementSlipFile(file);
    const reader = new FileReader();
    reader.onload = loadEvent =>
      setReplacementSlipPreview(loadEvent.target?.result as string);
    reader.readAsDataURL(file);
  };

  const saveEdit = async () => {
    if (!p) return;
    let slipBase64: string | undefined;
    let slipMimeType: string | undefined;
    if (replacementSlipFile) {
      const bytes = new Uint8Array(await replacementSlipFile.arrayBuffer());
      let binary = "";
      for (let index = 0; index < bytes.byteLength; index += 1)
        binary += String.fromCharCode(bytes[index]);
      slipBase64 = btoa(binary);
      slipMimeType = replacementSlipFile.type;
    }
    updateMutation.mutate({
      id: p.id,
      fullName: form.fullName.trim(),
      nickname: form.nickname.trim(),
      phone: form.phone.trim(),
      lineId: form.lineId.trim(),
      province: form.province.trim(),
      guestCount: Number(form.guestCount),
      message: form.message.trim(),
      paymentAmount: form.paymentAmount ? Number(form.paymentAmount) : null,
      paymentDate: form.paymentDate
        ? new Date(form.paymentDate).getTime()
        : null,
      slipBase64,
      slipMimeType,
      adminNote: form.adminNote.trim(),
    });
  };

  if (loading || !user || isLoading) return <LoadingScreen />;
  if (user.role !== "admin") return null;
  if (!p) return <NotFound onBack={() => navigate("/admin/participants")} />;

  const statusConfig = {
    pending: {
      label: "รอตรวจสอบ",
      cls: "status-pending",
      icon: <span>⏳</span>,
    },
    approved: {
      label: "อนุมัติแล้ว",
      cls: "status-approved",
      icon: <CheckCircle2 size={14} />,
    },
    rejected: {
      label: "ไม่ผ่านการอนุมัติ",
      cls: "status-rejected",
      icon: <XCircle size={14} />,
    },
  };
  const status = statusConfig[p.status];

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-20 border-b border-border/50 bg-white/90 backdrop-blur-sm">
        <div className="container flex items-center gap-3 py-3">
          <button
            type="button"
            onClick={() => navigate("/admin/participants")}
            className="rounded-xl p-2 transition-colors hover:bg-muted"
            aria-label="กลับไปรายชื่อ"
          >
            <ArrowLeft size={20} />
          </button>
          <div className="min-w-0 flex-1">
            <h1 className="truncate font-bold text-foreground">{p.fullName}</h1>
            <div
              className={`mt-0.5 inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium ${status.cls}`}
            >
              {status.icon} {status.label}
            </div>
          </div>
          {!isEditing && (
            <Button
              size="sm"
              className="rounded-lg text-xs"
              onClick={() => setIsEditing(true)}
            >
              <Edit2 size={14} className="mr-1" />
              แก้ไข
            </Button>
          )}
        </div>
      </header>

      <main className="container mx-auto max-w-2xl space-y-4 py-6">
        {isEditing && (
          <div className="rounded-2xl border border-primary/20 bg-primary/5 p-4 text-sm text-primary">
            กำลังแก้ไขข้อมูลผู้ลงทะเบียน กด “บันทึกการแก้ไข”
            เมื่อปรับข้อมูลเสร็จแล้ว
          </div>
        )}

        {p.status === "pending" && (
          <section className="rounded-2xl border border-border bg-white p-4 shadow-sm">
            <p className="mb-3 text-sm font-semibold text-foreground">
              การดำเนินการ
            </p>
            <div className="flex gap-3">
              <Button
                className="flex-1 rounded-xl bg-emerald-600 text-white hover:bg-emerald-700"
                onClick={() =>
                  approveMutation.mutate({ id: p.id, note: form.adminNote })
                }
                disabled={approveMutation.isPending}
              >
                <CheckCircle2 size={16} className="mr-2" />
                {approveMutation.isPending ? "กำลังอนุมัติ..." : "อนุมัติ"}
              </Button>
              <Button
                variant="outline"
                className="flex-1 rounded-xl border-red-200 text-red-600 hover:bg-red-50"
                onClick={() =>
                  rejectMutation.mutate({ id: p.id, note: form.adminNote })
                }
                disabled={rejectMutation.isPending}
              >
                <XCircle size={16} className="mr-2" />
                {rejectMutation.isPending ? "กำลังปฏิเสธ..." : "ปฏิเสธ"}
              </Button>
            </div>
          </section>
        )}

        {p.status === "approved" && (
          <section className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4">
            <div className="flex items-center gap-2 text-emerald-800">
              <CheckCircle2 size={18} />
              <p className="font-semibold">อนุมัติแล้ว</p>
            </div>
            {p.qrToken && (
              <p className="mt-2 flex items-center gap-2 text-sm text-emerald-700">
                <QrCode size={14} />
                <span className="font-mono text-xs">{p.qrToken}</span>
              </p>
            )}
            {p.checkedIn === 1 && (
              <p className="mt-2 text-sm text-emerald-700">
                เข้างานแล้ว เมื่อ{" "}
                {p.checkedInAt
                  ? new Date(p.checkedInAt).toLocaleString("th-TH")
                  : "-"}
              </p>
            )}
          </section>
        )}

        <InfoCard title="ข้อมูลส่วนตัว" icon={<Users size={16} />}>
          {isEditing ? (
            <div className="grid gap-4 sm:grid-cols-2">
              <EditField label="ชื่อ-นามสกุล *">
                <Input
                  value={form.fullName}
                  onChange={event => setField("fullName", event.target.value)}
                  className="rounded-xl"
                />
              </EditField>
              <EditField label="ชื่อเล่น">
                <Input
                  value={form.nickname}
                  onChange={event => setField("nickname", event.target.value)}
                  className="rounded-xl"
                />
              </EditField>
              <EditField label="โทรศัพท์ *">
                <Input
                  value={form.phone}
                  onChange={event => setField("phone", event.target.value)}
                  type="tel"
                  className="rounded-xl"
                />
              </EditField>
              <EditField label="LINE ID">
                <Input
                  value={form.lineId}
                  onChange={event => setField("lineId", event.target.value)}
                  className="rounded-xl"
                />
              </EditField>
              <EditField label="จังหวัด">
                <Input
                  value={form.province}
                  onChange={event => setField("province", event.target.value)}
                  className="rounded-xl"
                />
              </EditField>
              <EditField label="ผู้ติดตาม (คน)">
                <Input
                  value={form.guestCount}
                  onChange={event => setField("guestCount", event.target.value)}
                  type="number"
                  min="0"
                  max="10"
                  className="rounded-xl"
                />
              </EditField>
            </div>
          ) : (
            <div className="space-y-2">
              <InfoRow label="ชื่อ-สกุล" value={p.fullName} />
              <InfoRow label="ชื่อเล่น" value={p.nickname || "-"} />
              <InfoRow
                label="โทรศัพท์"
                value={p.phone}
                icon={<Phone size={12} />}
              />
              <InfoRow label="LINE ID" value={p.lineId || "-"} />
              <InfoRow
                label="จังหวัด"
                value={p.province || "-"}
                icon={<MapPin size={12} />}
              />
              <InfoRow label="ผู้ติดตาม" value={`${p.guestCount} คน`} />
              <InfoRow label="รวมทั้งหมด" value={`${p.totalCount} คน`} />
              <InfoRow
                label="ลงทะเบียนเมื่อ"
                value={new Date(p.createdAt).toLocaleString("th-TH")}
                icon={<Calendar size={12} />}
              />
            </div>
          )}
        </InfoCard>

        <InfoCard title="การชำระเงิน" icon={<CreditCard size={16} />}>
          {isEditing ? (
            <div className="grid gap-4 sm:grid-cols-2">
              <EditField label="จำนวนเงินที่โอน (บาท)">
                <Input
                  value={form.paymentAmount}
                  onChange={event =>
                    setField("paymentAmount", event.target.value)
                  }
                  type="number"
                  min="0"
                  className="rounded-xl"
                />
              </EditField>
              <EditField label="วันที่โอน">
                <Input
                  value={form.paymentDate}
                  onChange={event =>
                    setField("paymentDate", event.target.value)
                  }
                  type="date"
                  className="rounded-xl"
                />
              </EditField>
            </div>
          ) : (
            <div className="space-y-2">
              <InfoRow
                label="จำนวนเงิน"
                value={
                  p.paymentAmount
                    ? `${p.paymentAmount.toLocaleString()} บาท`
                    : "ไม่ระบุ"
                }
              />
              <InfoRow
                label="วันที่โอน"
                value={
                  p.paymentDate
                    ? new Date(p.paymentDate).toLocaleDateString("th-TH")
                    : "ไม่ระบุ"
                }
              />
            </div>
          )}
          {isEditing && (
            <div className="mt-4">
              <EditField label="เปลี่ยนสลิปโอนเงิน (ไม่บังคับ)">
                <div
                  onClick={() => replacementSlipInputRef.current?.click()}
                  className={`cursor-pointer rounded-2xl border-2 border-dashed p-4 text-center transition-colors ${replacementSlipPreview ? "border-primary/50 bg-primary/5" : "border-border hover:border-primary/40 hover:bg-muted/50"}`}
                >
                  {replacementSlipPreview ? (
                    <div className="relative">
                      <img
                        src={replacementSlipPreview}
                        alt="ตัวอย่างสลิปใหม่"
                        className="mx-auto max-h-48 rounded-xl object-contain"
                      />
                      <button
                        type="button"
                        onClick={event => {
                          event.stopPropagation();
                          setReplacementSlipFile(null);
                          setReplacementSlipPreview(null);
                          if (replacementSlipInputRef.current)
                            replacementSlipInputRef.current.value = "";
                        }}
                        className="absolute right-1 top-1 rounded-full bg-red-600 p-1 text-white"
                        aria-label="ยกเลิกการเปลี่ยนสลิป"
                      >
                        <X size={14} />
                      </button>
                      <p className="mt-2 text-xs font-medium text-primary">
                        พร้อมเปลี่ยนสลิปเมื่อบันทึก
                      </p>
                    </div>
                  ) : (
                    <>
                      <Upload
                        size={24}
                        className="mx-auto mb-2 text-muted-foreground"
                      />
                      <p className="text-sm font-medium">
                        คลิกเพื่อเลือกสลิปใหม่
                      </p>
                      <p className="mt-1 text-xs text-muted-foreground">
                        หากไม่เลือก ระบบจะใช้สลิปเดิม
                      </p>
                    </>
                  )}
                </div>
                <input
                  ref={replacementSlipInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleReplacementSlip}
                />
              </EditField>
            </div>
          )}
          {p.slipUrl && (
            <a
              href={p.slipUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-3 block"
            >
              <img
                src={p.slipUrl}
                alt="สลิปโอนเงิน"
                className="max-h-64 rounded-xl border border-border object-contain transition-opacity hover:opacity-90"
              />
              <span className="mt-1 flex items-center gap-1 text-xs text-primary">
                <ExternalLink size={12} />
                ดูภาพสลิปขนาดเต็ม
              </span>
            </a>
          )}
          {!p.slipUrl && (
            <p className="mt-3 text-sm text-muted-foreground">
              ไม่มีสลิปโอนเงิน
            </p>
          )}
        </InfoCard>

        <InfoCard title="ข้อความและหมายเหตุ" icon={<MessageSquare size={16} />}>
          {isEditing ? (
            <div className="space-y-4">
              <EditField label="ข้อความถึงเพื่อนร่วมรุ่น">
                <Textarea
                  value={form.message}
                  onChange={event => setField("message", event.target.value)}
                  className="min-h-24 rounded-xl resize-none"
                />
              </EditField>
              <EditField label="หมายเหตุผู้ดูแล">
                <Textarea
                  value={form.adminNote}
                  onChange={event => setField("adminNote", event.target.value)}
                  className="min-h-24 rounded-xl resize-none"
                />
              </EditField>
            </div>
          ) : (
            <div className="space-y-4">
              <InfoRow label="ข้อความถึงเพื่อน" value={p.message || "-"} />
              <InfoRow label="หมายเหตุผู้ดูแล" value={p.adminNote || "-"} />
            </div>
          )}
        </InfoCard>

        {isEditing && (
          <div className="flex gap-3">
            <Button
              type="button"
              variant="outline"
              className="flex-1 rounded-xl py-6"
              onClick={cancelEdit}
              disabled={updateMutation.isPending}
            >
              <X size={16} className="mr-2" />
              ยกเลิก
            </Button>
            <Button
              type="button"
              className="flex-1 rounded-xl py-6"
              onClick={saveEdit}
              disabled={updateMutation.isPending}
            >
              <Save size={16} className="mr-2" />
              {updateMutation.isPending ? "กำลังบันทึก..." : "บันทึกการแก้ไข"}
            </Button>
          </div>
        )}

        {p.status !== "pending" && (
          <section className="rounded-2xl border border-border bg-white p-4 shadow-sm">
            <p className="mb-3 text-sm font-semibold text-foreground">
              เปลี่ยนสถานะ
            </p>
            <div className="flex gap-2">
              {p.status !== "approved" && (
                <Button
                  size="sm"
                  className="rounded-lg bg-emerald-600 text-white hover:bg-emerald-700"
                  onClick={() =>
                    approveMutation.mutate({ id: p.id, note: form.adminNote })
                  }
                >
                  <CheckCircle2 size={14} className="mr-1" />
                  อนุมัติ
                </Button>
              )}
              {p.status !== "rejected" && (
                <Button
                  size="sm"
                  variant="outline"
                  className="rounded-lg border-red-200 text-red-600 hover:bg-red-50"
                  onClick={() =>
                    rejectMutation.mutate({ id: p.id, note: form.adminNote })
                  }
                >
                  <XCircle size={14} className="mr-1" />
                  ปฏิเสธ
                </Button>
              )}
            </div>
          </section>
        )}

        <section className="rounded-2xl border border-red-100 bg-white p-4 shadow-sm">
          <button
            type="button"
            onClick={() => setShowDeleteConfirm(true)}
            className="flex items-center gap-2 text-sm text-red-600 transition-colors hover:text-red-700"
          >
            <Trash2 size={15} />
            ลบข้อมูลผู้ลงทะเบียนนี้
          </button>
        </section>
      </main>

      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>ยืนยันการลบข้อมูล</AlertDialogTitle>
            <AlertDialogDescription>
              ข้อมูลของ “{p.fullName}” จะถูกลบถาวร รวมถึงสถานะและ QR Code
              และไม่สามารถกู้คืนได้
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleteMutation.isPending}>
              ยกเลิก
            </AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 hover:bg-red-700"
              onClick={() => deleteMutation.mutate({ id: p.id })}
              disabled={deleteMutation.isPending}
            >
              <Trash2 size={15} className="mr-1" />
              {deleteMutation.isPending ? "กำลังลบ..." : "ยืนยันลบ"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function InfoCard({
  title,
  icon,
  children,
}: {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-2xl border border-border bg-white p-4 shadow-sm">
      <div className="mb-3 flex items-center gap-2 border-b border-border pb-2">
        <span className="text-primary">{icon}</span>
        <h2 className="text-sm font-semibold text-foreground">{title}</h2>
      </div>
      {children}
    </section>
  );
}

function InfoRow({
  label,
  value,
  icon,
}: {
  label: string;
  value: string;
  icon?: React.ReactNode;
}) {
  return (
    <div className="flex items-start justify-between gap-4">
      <span className="shrink-0 text-xs text-muted-foreground">{label}</span>
      <span className="flex items-center gap-1 text-right text-sm font-medium text-foreground">
        {icon}
        {value}
      </span>
    </div>
  );
}

function EditField({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <Label className="text-sm font-medium">{label}</Label>
      {children}
    </div>
  );
}

function LoadingScreen() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background">
      <div className="text-3xl animate-spin">⏳</div>
    </div>
  );
}

function NotFound({ onBack }: { onBack: () => void }) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background">
      <div className="text-center">
        <p className="mb-3 text-xl font-bold">ไม่พบข้อมูลผู้ลงทะเบียน</p>
        <Button variant="outline" onClick={onBack}>
          กลับไปรายชื่อ
        </Button>
      </div>
    </div>
  );
}
