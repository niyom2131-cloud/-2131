import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { ArrowLeft, ScanLine, CheckCircle2, XCircle, AlertCircle, Search } from "lucide-react";

type ScanResult = {
  success: boolean;
  alreadyCheckedIn: boolean;
  participant?: {
    fullName: string;
    nickname?: string | null;
    classYear?: string | null;
    shirtSize: string;
    guestCount: number;
    totalCount: number;
    foodType: string;
    checkedIn: number;
  };
  error?: string;
};

const FOOD_LABELS: Record<string, string> = { general: "ทั่วไป", muslim: "มุสลิม", vegetarian: "มังสวิรัติ" };

export default function AdminQrScanner() {
  const [, navigate] = useLocation();
  const { user, loading } = useAuth();
  const [token, setToken] = useState("");
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);

  useEffect(() => {
    if (!loading && (!user || user.role !== "admin")) navigate("/admin");
  }, [user, loading, navigate]);

  const checkInMutation = trpc.admin.checkIn.useMutation({
    onSuccess: (data) => {
      setScanResult({
        success: data.success,
        alreadyCheckedIn: data.alreadyCheckedIn,
        participant: data.participant as any,
      });
      if (data.success) toast.success(`✅ Check-in สำเร็จ: ${data.participant.fullName}`);
      else if (data.alreadyCheckedIn) toast.warning(`⚠️ ${data.participant.fullName} เข้างานแล้ว`);
    },
    onError: (e) => {
      setScanResult({ success: false, alreadyCheckedIn: false, error: e.message });
      toast.error("❌ " + e.message);
    },
  });

  const handleScan = () => {
    if (!token.trim()) { toast.error("กรุณากรอก QR Token"); return; }
    setScanResult(null);
    checkInMutation.mutate({ qrToken: token.trim() });
  };

  const handleReset = () => { setToken(""); setScanResult(null); };

  if (loading || !user) return <LoadingScreen />;
  if (user.role !== "admin") return null;

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-20 border-b border-border/50 bg-white/90 backdrop-blur-sm">
        <div className="container flex items-center gap-3 py-3">
          <button onClick={() => navigate("/admin/dashboard")} className="p-2 rounded-xl hover:bg-muted transition-colors">
            <ArrowLeft size={20} />
          </button>
          <div>
            <h1 className="font-bold text-foreground">สแกน QR Code</h1>
            <p className="text-xs text-muted-foreground">Check-in ผู้เข้าร่วมงาน</p>
          </div>
        </div>
      </header>

      <div className="container py-8 max-w-md mx-auto">
        {/* Scanner Area */}
        <div className="bg-white rounded-3xl border border-border p-6 shadow-sm mb-6">
          <div className="flex items-center gap-2 mb-4">
            <ScanLine size={20} className="text-primary" />
            <h2 className="font-bold text-foreground">กรอก QR Token</h2>
          </div>

          {/* QR Camera hint */}
          <div className="bg-muted/50 rounded-2xl p-4 mb-4 text-center">
            <ScanLine size={40} className="mx-auto text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground">
              สแกน QR Code ด้วยกล้องแล้วคัดลอก token<br />
              หรือกรอก token ด้านล่างโดยตรง
            </p>
          </div>

          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={token}
                onChange={(e) => setToken(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleScan()}
                placeholder="วาง QR Token ที่นี่..."
                className="pl-9 rounded-xl font-mono text-sm"
              />
            </div>
            <Button
              onClick={handleScan}
              className="rounded-xl px-4"
              disabled={checkInMutation.isPending}
            >
              {checkInMutation.isPending ? "⏳" : "✓"}
            </Button>
          </div>
        </div>

        {/* Result */}
        {scanResult && (
          <div className={`rounded-3xl border p-6 ${
            scanResult.alreadyCheckedIn
              ? "bg-amber-50 border-amber-200"
              : scanResult.success
              ? "bg-emerald-50 border-emerald-200"
              : "bg-red-50 border-red-200"
          }`}>
            <div className="flex items-center gap-3 mb-4">
              {scanResult.alreadyCheckedIn ? (
                <AlertCircle size={28} className="text-amber-600" />
              ) : scanResult.success ? (
                <CheckCircle2 size={28} className="text-emerald-600" />
              ) : (
                <XCircle size={28} className="text-red-600" />
              )}
              <div>
                <p className={`text-lg font-bold ${
                  scanResult.alreadyCheckedIn ? "text-amber-800" : scanResult.success ? "text-emerald-800" : "text-red-800"
                }`}>
                  {scanResult.alreadyCheckedIn
                    ? "เข้างานแล้ว!"
                    : scanResult.success
                    ? "Check-in สำเร็จ! ✅"
                    : "ไม่สำเร็จ ❌"}
                </p>
                {scanResult.error && <p className="text-sm text-red-700">{scanResult.error}</p>}
              </div>
            </div>

            {scanResult.participant && (
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">ชื่อ</span>
                  <span className="font-bold text-foreground">
                    {scanResult.participant.fullName}
                    {scanResult.participant.nickname && ` (${scanResult.participant.nickname})`}
                  </span>
                </div>
                {scanResult.participant.classYear && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">รุ่น</span>
                    <span className="font-medium text-foreground">{scanResult.participant.classYear}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-muted-foreground">จำนวนรวม</span>
                  <span className="font-medium text-foreground">{scanResult.participant.totalCount} คน</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">ขนาดเสื้อ</span>
                  <span className="font-bold text-foreground text-lg">{scanResult.participant.shirtSize}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">อาหาร</span>
                  <span className="font-medium text-foreground">{FOOD_LABELS[scanResult.participant.foodType] || scanResult.participant.foodType}</span>
                </div>
              </div>
            )}

            <Button
              variant="outline"
              className="w-full mt-4 rounded-xl"
              onClick={handleReset}
            >
              สแกนคนถัดไป
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}

function LoadingScreen() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="animate-spin text-3xl">⏳</div>
    </div>
  );
}
