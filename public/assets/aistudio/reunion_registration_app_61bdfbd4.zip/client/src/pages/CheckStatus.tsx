import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Phone, Search, CheckCircle2, Clock, XCircle, QrCode } from "lucide-react";

const STATUS_CONFIG = {
  pending: { label: "รอตรวจสอบ", icon: Clock, color: "text-amber-600", bg: "bg-amber-50 border-amber-200" },
  approved: { label: "อนุมัติแล้ว ✓", icon: CheckCircle2, color: "text-emerald-600", bg: "bg-emerald-50 border-emerald-200" },
  rejected: { label: "ไม่ผ่านการอนุมัติ", icon: XCircle, color: "text-red-600", bg: "bg-red-50 border-red-200" },
};

export default function CheckStatus() {
  const [, navigate] = useLocation();
  const [phone, setPhone] = useState("");
  const [searchPhone, setSearchPhone] = useState("");

  const { data, isLoading, error } = trpc.registration.checkStatus.useQuery(
    { phone: searchPhone },
    { enabled: !!searchPhone }
  );

  const handleSearch = () => {
    if (phone.trim().length >= 9) setSearchPhone(phone.trim());
  };

  const config = data ? STATUS_CONFIG[data.status] : null;

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <div className="geo-shape geo-blue" style={{ width: 350, height: 350, top: -80, right: -80 }} />
      <div className="geo-shape geo-pink" style={{ width: 280, height: 280, bottom: 100, left: -80 }} />

      <header className="sticky top-0 z-20 border-b border-border/50 bg-white/80 backdrop-blur-sm">
        <div className="container flex items-center gap-3 py-4">
          <button onClick={() => navigate("/")} className="p-2 rounded-xl hover:bg-muted transition-colors">
            <ArrowLeft size={20} />
          </button>
          <div>
            <h1 className="font-bold text-foreground">ตรวจสอบสถานะ</h1>
            <p className="text-xs text-muted-foreground">ค้นหาด้วยหมายเลขโทรศัพท์</p>
          </div>
        </div>
      </header>

      <div className="container py-10 max-w-md mx-auto relative z-10">
        <div className="bg-white rounded-3xl border border-border p-6 shadow-sm mb-6">
          <div className="flex items-center gap-2 mb-2">
            <Phone size={18} className="text-primary" />
            <h2 className="font-bold text-foreground">ค้นหาการลงทะเบียน</h2>
          </div>
          <p className="text-sm text-muted-foreground mb-4">กรอกเบอร์โทรศัพท์ที่ใช้ลงทะเบียน</p>
          <div className="flex gap-2">
            <Input
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="08X-XXX-XXXX"
              type="tel"
              className="rounded-xl flex-1"
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
            />
            <Button onClick={handleSearch} className="rounded-xl px-4" disabled={isLoading}>
              <Search size={16} />
            </Button>
          </div>
        </div>

        {isLoading && (
          <div className="text-center py-8 text-muted-foreground">
            <div className="animate-spin text-2xl mb-2">⏳</div>
            <p>กำลังค้นหา...</p>
          </div>
        )}

        {searchPhone && !isLoading && data === null && (
          <div className="bg-white rounded-3xl border border-border p-6 shadow-sm text-center">
            <div className="text-4xl mb-3">🔍</div>
            <p className="font-semibold text-foreground mb-1">ไม่พบข้อมูลการลงทะเบียน</p>
            <p className="text-sm text-muted-foreground">กรุณาตรวจสอบเบอร์โทรศัพท์อีกครั้ง</p>
          </div>
        )}

        {data && config && (
          <div className="space-y-4">
            <div className={`rounded-3xl border p-6 ${config.bg}`}>
              <div className="flex items-center gap-3 mb-4">
                <config.icon size={24} className={config.color} />
                <div>
                  <p className="text-sm text-muted-foreground">สถานะการลงทะเบียน</p>
                  <p className={`text-lg font-bold ${config.color}`}>{config.label}</p>
                </div>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">ชื่อ-สกุล</span>
                  <span className="font-medium text-foreground">{data.fullName}</span>
                </div>
                {data.nickname && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">ชื่อเล่น</span>
                    <span className="font-medium text-foreground">{data.nickname}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-muted-foreground">หมายเลขอ้างอิง</span>
                  <span className="font-mono font-bold text-foreground">#{data.id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">ลงทะเบียนเมื่อ</span>
                  <span className="font-medium text-foreground">
                    {new Date(data.createdAt).toLocaleDateString("th-TH", { day: "numeric", month: "short", year: "numeric" })}
                  </span>
                </div>
              </div>
            </div>

            {data.status === "approved" && (
              <Button
                className="w-full rounded-xl py-5"
                onClick={() => navigate("/my-qr?phone=" + encodeURIComponent(phone))}
              >
                <QrCode size={18} className="mr-2" />
                ดู QR Code สำหรับเข้างาน
              </Button>
            )}

            {data.status === "pending" && (
              <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 text-sm text-amber-800">
                <p className="font-semibold mb-1">⏳ กำลังรอการตรวจสอบ</p>
                <p>ผู้ดูแลจะตรวจสอบและอนุมัติภายใน 24 ชั่วโมง</p>
              </div>
            )}

            {data.status === "rejected" && (
              <div className="bg-red-50 border border-red-200 rounded-2xl p-4 text-sm text-red-800">
                <p className="font-semibold mb-1">❌ ไม่ผ่านการอนุมัติ</p>
                <p>กรุณาติดต่อผู้ดูแลระบบเพื่อสอบถามรายละเอียด</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
