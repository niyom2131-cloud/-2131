import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import {
  ArrowLeft,
  Search,
  Download,
  CheckCircle2,
  XCircle,
  Eye,
  Clock,
  UserPlus,
} from "lucide-react";
import * as XLSX from "xlsx";

type StatusFilter = "all" | "pending" | "approved" | "rejected";

const STATUS_CONFIG = {
  pending: { label: "รอตรวจสอบ", cls: "status-pending" },
  approved: { label: "อนุมัติแล้ว", cls: "status-approved" },
  rejected: { label: "ไม่ผ่าน", cls: "status-rejected" },
};

export default function AdminParticipants() {
  const [location, navigate] = useLocation();
  const { user, loading } = useAuth();
  const [search, setSearch] = useState("");
  const [searchInput, setSearchInput] = useState("");
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");

  useEffect(() => {
    const params = new URLSearchParams(location.split("?")[1] || "");
    const s = params.get("status") as StatusFilter;
    if (s && ["all", "pending", "approved", "rejected"].includes(s))
      setStatusFilter(s);
  }, [location]);

  useEffect(() => {
    if (!loading && (!user || user.role !== "admin")) navigate("/admin");
  }, [user, loading, navigate]);

  const {
    data: participants,
    isLoading,
    refetch,
  } = trpc.admin.list.useQuery(
    { search: search || undefined, status: statusFilter },
    { enabled: !!user && user.role === "admin", refetchInterval: 30000 }
  );

  const { data: exportData } = trpc.admin.exportData.useQuery(
    { status: statusFilter },
    { enabled: !!user && user.role === "admin" }
  );

  const handleExport = () => {
    if (!exportData || exportData.length === 0) {
      toast.error("ไม่มีข้อมูลสำหรับ Export");
      return;
    }
    // exportData already has Thai column names from the server
    const ws = XLSX.utils.json_to_sheet(exportData);

    // ปรับความกว้างคอลัมน์อัตโนมัติ
    const colWidths = Object.keys(exportData[0] || {}).map(key => ({
      wch: Math.max(key.length * 2, 12),
    }));
    ws["!cols"] = colWidths;

    const wb = XLSX.utils.book_new();
    const sheetLabel =
      statusFilter === "all"
        ? "ผู้ลงทะเบียนทั้งหมด"
        : statusFilter === "approved"
          ? "อนุมัติแล้ว"
          : statusFilter === "pending"
            ? "รอตรวจสอบ"
            : "ปฏิเสธ";

    XLSX.utils.book_append_sheet(wb, ws, sheetLabel);

    // เพิ่ม sheet สรุป
    const summaryData = [
      { รายการ: "ทั้งหมด", จำนวน: participants?.length ?? exportData.length },
      { รายการ: "Export เมื่อ", จำนวน: new Date().toLocaleString("th-TH") },
    ];
    const wsSummary = XLSX.utils.json_to_sheet(summaryData);
    XLSX.utils.book_append_sheet(wb, wsSummary, "สรุป");

    XLSX.writeFile(
      wb,
      `participants-${statusFilter}-${new Date().toISOString().split("T")[0]}.xlsx`
    );
    toast.success(`Export Excel สำเร็จ! (${exportData.length} รายการ)`);
  };

  if (loading || !user) return <LoadingScreen />;
  if (user.role !== "admin") return null;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-20 border-b border-border/50 bg-white/90 backdrop-blur-sm">
        <div className="container flex items-center gap-3 py-3">
          <button
            onClick={() => navigate("/admin/dashboard")}
            className="p-2 rounded-xl hover:bg-muted transition-colors"
          >
            <ArrowLeft size={20} />
          </button>
          <div className="flex-1">
            <h1 className="font-bold text-foreground">รายชื่อผู้ลงทะเบียน</h1>
            <p className="text-xs text-muted-foreground">
              {participants?.length ?? 0} รายการ
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              size="sm"
              className="rounded-lg text-xs"
              onClick={() => navigate("/admin/register")}
            >
              <UserPlus size={14} className="mr-1.5" />
              <span className="hidden sm:inline">ลงทะเบียนแทน</span>
              <span className="sm:hidden">เพิ่ม</span>
            </Button>
            <Button
              size="sm"
              className="rounded-lg text-xs bg-emerald-600 hover:bg-emerald-700 text-white"
              onClick={handleExport}
            >
              <Download size={14} className="mr-1.5" />
              <span className="hidden sm:inline">Export Excel</span>
              <span className="sm:hidden">Export</span>
            </Button>
          </div>
        </div>

        {/* Search & Filter */}
        <div className="container pb-3 space-y-2">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search
                size={15}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
              />
              <Input
                value={searchInput}
                onChange={e => setSearchInput(e.target.value)}
                onKeyDown={e => {
                  if (e.key === "Enter") setSearch(searchInput);
                }}
                placeholder="ค้นหาชื่อ, เบอร์, จังหวัด..."
                className="pl-9 rounded-xl text-sm"
              />
            </div>
            <Button
              size="sm"
              className="rounded-xl"
              onClick={() => setSearch(searchInput)}
            >
              <Search size={14} />
            </Button>
          </div>
          <div className="flex gap-1.5 overflow-x-auto pb-1">
            {(["all", "pending", "approved", "rejected"] as StatusFilter[]).map(
              s => (
                <button
                  key={s}
                  onClick={() => setStatusFilter(s)}
                  className={`px-3 py-1 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                    statusFilter === s
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted text-muted-foreground hover:bg-muted/80"
                  }`}
                >
                  {s === "all"
                    ? "ทั้งหมด"
                    : s === "pending"
                      ? "⏳ รอตรวจสอบ"
                      : s === "approved"
                        ? "✅ อนุมัติแล้ว"
                        : "❌ ไม่ผ่าน"}
                </button>
              )
            )}
          </div>
        </div>
      </header>

      <div className="container py-4 max-w-5xl">
        {isLoading ? (
          <div className="space-y-3">
            {[...Array(5)].map((_, i) => (
              <div
                key={i}
                className="bg-white rounded-2xl border border-border p-4 animate-pulse"
              >
                <div className="h-4 bg-muted rounded w-1/3 mb-2" />
                <div className="h-3 bg-muted rounded w-1/2" />
              </div>
            ))}
          </div>
        ) : participants?.length === 0 ? (
          <div className="text-center py-16">
            <div className="text-4xl mb-3">📋</div>
            <p className="font-semibold text-foreground mb-1">ไม่พบรายการ</p>
            <p className="text-sm text-muted-foreground">
              ลองเปลี่ยนคำค้นหาหรือตัวกรอง
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {participants?.map(p => {
              const sc = STATUS_CONFIG[p.status];
              return (
                <div
                  key={p.id}
                  className="bg-white rounded-2xl border border-border p-4 shadow-sm hover:shadow-md transition-shadow cursor-pointer"
                  onClick={() => navigate(`/admin/participants/${p.id}`)}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <span className="font-bold text-foreground truncate">
                          {p.fullName}
                        </span>
                        {p.nickname && (
                          <span className="text-xs text-muted-foreground">
                            ({p.nickname})
                          </span>
                        )}
                        <span
                          className={`text-xs px-2 py-0.5 rounded-full font-medium ${sc.cls}`}
                        >
                          {sc.label}
                        </span>
                      </div>
                      <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                        <span>📞 {p.phone}</span>
                        {p.province && <span>📍 {p.province}</span>}
                        <span>👥 {p.totalCount} คน</span>
                        {p.paymentAmount ? (
                          <span>💰 {p.paymentAmount.toLocaleString()} บาท</span>
                        ) : (
                          <span className="text-amber-500">
                            ⚠️ ยังไม่มีข้อมูลการชำระ
                          </span>
                        )}
                        {p.slipUrl && (
                          <span className="text-emerald-600">📎 มีสลิป</span>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      {p.checkedIn === 1 && (
                        <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full">
                          เข้างานแล้ว
                        </span>
                      )}
                      <Eye size={16} className="text-muted-foreground" />
                    </div>
                  </div>
                  <div className="mt-2 text-xs text-muted-foreground">
                    ลงทะเบียน{" "}
                    {new Date(p.createdAt).toLocaleString("th-TH", {
                      day: "numeric",
                      month: "short",
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function LoadingScreen() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="animate-spin text-3xl">⏳</div>
    </div>
  );
}
