import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import {
  Users,
  CheckCircle2,
  Clock,
  XCircle,
  MapPin,
  QrCode,
  ScanLine,
  LogOut,
  Download,
  Eye,
  X,
  ZoomIn,
  AlertCircle,
  UserPlus,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import * as XLSX from "xlsx";

// ─── Slip Lightbox ────────────────────────────────────────────────────────────
function SlipLightbox({ url, onClose }: { url: string; onClose: () => void }) {
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="relative max-w-2xl w-full"
        onClick={e => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute -top-10 right-0 text-white/80 hover:text-white transition-colors"
        >
          <X size={28} />
        </button>
        <img
          src={url}
          alt="สลิปโอนเงิน"
          className="w-full max-h-[80vh] object-contain rounded-2xl shadow-2xl"
        />
        <a
          href={url}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-3 flex items-center justify-center gap-2 text-white/70 hover:text-white text-sm transition-colors"
        >
          <ZoomIn size={14} />
          เปิดรูปขนาดเต็ม
        </a>
      </div>
    </div>
  );
}

// ─── Pending Card ─────────────────────────────────────────────────────────────
function PendingCard({
  p,
  onApprove,
  onReject,
  onViewDetail,
}: {
  p: {
    id: number;
    fullName: string;
    nickname?: string | null;
    phone: string;
    province?: string | null;
    totalCount: number;
    paymentAmount?: number | null;
    paymentDate?: number | null;
    slipUrl?: string | null;
    createdAt: Date | number;
  };
  onApprove: (id: number, note: string) => void;
  onReject: (id: number, note: string) => void;
  onViewDetail: (id: number) => void;
}) {
  const [note, setNote] = useState("");
  const [showNote, setShowNote] = useState(false);
  const [slipOpen, setSlipOpen] = useState(false);

  return (
    <>
      {slipOpen && p.slipUrl && (
        <SlipLightbox url={p.slipUrl} onClose={() => setSlipOpen(false)} />
      )}
      <div className="bg-white rounded-2xl border border-amber-200 shadow-sm overflow-hidden">
        {/* Top bar */}
        <div className="bg-amber-50 px-4 py-2 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock size={14} className="text-amber-600" />
            <span className="text-xs font-semibold text-amber-700">
              รอตรวจสอบ
            </span>
          </div>
          <span className="text-xs text-muted-foreground">
            {new Date(
              typeof p.createdAt === "number" ? p.createdAt : p.createdAt
            ).toLocaleString("th-TH", {
              day: "numeric",
              month: "short",
              hour: "2-digit",
              minute: "2-digit",
            })}
          </span>
        </div>

        <div className="p-4">
          {/* Info */}
          <div className="flex items-start justify-between gap-3 mb-3">
            <div className="flex-1 min-w-0">
              <p className="font-bold text-foreground truncate">
                {p.fullName}
                {p.nickname && (
                  <span className="text-sm font-normal text-muted-foreground ml-1">
                    ({p.nickname})
                  </span>
                )}
              </p>
              <div className="flex flex-wrap gap-x-3 gap-y-1 mt-1 text-xs text-muted-foreground">
                <span>📞 {p.phone}</span>
                {p.province && <span>📍 {p.province}</span>}
                <span>👥 {p.totalCount} คน</span>
                {p.paymentAmount ? (
                  <span className="text-emerald-700 font-medium">
                    💰 {p.paymentAmount.toLocaleString()} บาท
                  </span>
                ) : (
                  <span className="text-amber-600">⚠️ ไม่ระบุยอด</span>
                )}
              </div>
            </div>
            <button
              onClick={() => onViewDetail(p.id)}
              className="p-1.5 rounded-lg hover:bg-muted transition-colors flex-shrink-0"
              title="ดูรายละเอียด"
            >
              <Eye size={16} className="text-muted-foreground" />
            </button>
          </div>

          {/* Slip preview */}
          {p.slipUrl ? (
            <div
              className="relative mb-3 cursor-pointer group"
              onClick={() => setSlipOpen(true)}
            >
              <img
                src={p.slipUrl}
                alt="สลิปโอนเงิน"
                className="w-full max-h-48 object-contain rounded-xl border border-border bg-muted group-hover:opacity-90 transition-opacity"
              />
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="bg-black/60 text-white rounded-xl px-3 py-1.5 text-xs flex items-center gap-1.5">
                  <ZoomIn size={13} />
                  คลิกเพื่อขยาย
                </div>
              </div>
            </div>
          ) : (
            <div className="mb-3 bg-muted/50 rounded-xl p-3 flex items-center gap-2 text-xs text-muted-foreground">
              <AlertCircle size={14} />
              ไม่มีสลิปโอนเงิน
            </div>
          )}

          {/* Note toggle */}
          {showNote && (
            <Textarea
              value={note}
              onChange={e => setNote(e.target.value)}
              placeholder="หมายเหตุ (ไม่บังคับ)..."
              className="mb-3 rounded-xl text-sm resize-none"
              rows={2}
            />
          )}

          {/* Action buttons */}
          <div className="flex gap-2">
            <Button
              size="sm"
              className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl"
              onClick={() => onApprove(p.id, note)}
            >
              <CheckCircle2 size={14} className="mr-1.5" />
              อนุมัติ
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="flex-1 border-red-200 text-red-600 hover:bg-red-50 rounded-xl"
              onClick={() => onReject(p.id, note)}
            >
              <XCircle size={14} className="mr-1.5" />
              ปฏิเสธ
            </Button>
            <button
              onClick={() => setShowNote(!showNote)}
              className="px-3 py-1.5 rounded-xl border border-border text-xs text-muted-foreground hover:bg-muted transition-colors"
              title="เพิ่มหมายเหตุ"
            >
              📝
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

// ─── Main Dashboard ───────────────────────────────────────────────────────────
export default function AdminDashboard() {
  const [, navigate] = useLocation();
  const { user, loading, logout } = useAuth();
  const utils = trpc.useUtils();

  useEffect(() => {
    if (!loading && (!user || user.role !== "admin")) navigate("/admin");
  }, [user, loading, navigate]);

  const { data: stats, isLoading: statsLoading } = trpc.admin.stats.useQuery(
    undefined,
    {
      enabled: !!user && user.role === "admin",
      refetchInterval: 30000,
    }
  );

  const { data: pendingList, isLoading: pendingLoading } =
    trpc.admin.list.useQuery(
      { status: "pending" },
      { enabled: !!user && user.role === "admin", refetchInterval: 15000 }
    );

  const { data: exportAll } = trpc.admin.exportData.useQuery(
    { status: "all" },
    { enabled: !!user && user.role === "admin" }
  );

  const approveMutation = trpc.admin.approve.useMutation({
    onSuccess: () => {
      toast.success("✅ อนุมัติสำเร็จ! QR Code ถูกสร้างแล้ว");
      utils.admin.list.invalidate();
      utils.admin.stats.invalidate();
    },
    onError: e => toast.error("เกิดข้อผิดพลาด: " + e.message),
  });

  const rejectMutation = trpc.admin.reject.useMutation({
    onSuccess: () => {
      toast.success("ปฏิเสธการลงทะเบียนแล้ว");
      utils.admin.list.invalidate();
      utils.admin.stats.invalidate();
    },
    onError: e => toast.error("เกิดข้อผิดพลาด: " + e.message),
  });

  const handleExportAll = () => {
    if (!exportAll || exportAll.length === 0) {
      toast.error("ไม่มีข้อมูลสำหรับ Export");
      return;
    }
    const ws = XLSX.utils.json_to_sheet(exportAll);
    const colWidths = Object.keys(exportAll[0] || {}).map(key => ({
      wch: Math.max(key.length * 2, 12),
    }));
    ws["!cols"] = colWidths;

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "ผู้ลงทะเบียนทั้งหมด");

    // Sheet สรุปสถิติ
    const summaryRows = [
      { รายการ: "ลงทะเบียนทั้งหมด", จำนวน: stats?.total ?? 0 },
      { รายการ: "อนุมัติแล้ว", จำนวน: stats?.approved ?? 0 },
      { รายการ: "รอตรวจสอบ", จำนวน: stats?.pending ?? 0 },
      { รายการ: "ปฏิเสธ", จำนวน: stats?.rejected ?? 0 },
      {
        รายการ: "ผู้เข้าร่วมรวม (รวมผู้ติดตาม)",
        จำนวน: stats?.totalGuests ?? 0,
      },
      { รายการ: "Export เมื่อ", จำนวน: new Date().toLocaleString("th-TH") },
    ];
    const wsSummary = XLSX.utils.json_to_sheet(summaryRows);
    XLSX.utils.book_append_sheet(wb, wsSummary, "สรุปสถิติ");

    XLSX.writeFile(
      wb,
      `reunion-2569-all-${new Date().toISOString().split("T")[0]}.xlsx`
    );
    toast.success(`Export Excel สำเร็จ! (${exportAll.length} รายการ)`);
  };

  if (loading || !user) return <LoadingScreen />;
  if (user.role !== "admin") return null;

  return (
    <div className="min-h-screen bg-background">
      {/* Admin Top Bar */}
      <header className="sticky top-0 z-20 border-b border-border/50 bg-white/90 backdrop-blur-sm">
        <div className="container flex items-center justify-between py-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center text-white font-bold text-xs">
              นนส.
            </div>
            <div>
              <p className="font-bold text-sm text-foreground">
                ระบบจัดการ Admin
              </p>
              <p className="text-xs text-muted-foreground">
                งานเลี้ยงรุ่น 2569
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              size="sm"
              className="rounded-lg text-xs"
              onClick={() => navigate("/admin/register")}
            >
              <UserPlus size={13} className="mr-1" />
              ลงทะเบียนแทน
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="rounded-lg text-xs bg-emerald-50 border-emerald-200 text-emerald-700 hover:bg-emerald-100"
              onClick={handleExportAll}
            >
              <Download size={13} className="mr-1" />
              Export Excel
            </Button>
            <span className="text-xs text-muted-foreground hidden sm:block">
              {user.name}
            </span>
            <Button
              variant="outline"
              size="sm"
              className="rounded-lg text-xs"
              onClick={logout}
            >
              <LogOut size={14} className="mr-1" />
              ออก
            </Button>
          </div>
        </div>
        {/* Nav tabs */}
        <div className="container pb-2">
          <div className="flex gap-1 overflow-x-auto">
            {[
              { path: "/admin/dashboard", label: "ภาพรวม", active: true },
              { path: "/admin/register", label: "ลงทะเบียนแทน", active: false },
              { path: "/admin/participants", label: "รายชื่อ", active: false },
              { path: "/admin/scanner", label: "สแกน QR", active: false },
            ].map(item => (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                className={`px-4 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
                  item.active
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:bg-muted"
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </header>

      <div className="container py-6 max-w-5xl">
        {/* Title */}
        <div className="mb-6">
          <h1 className="text-2xl font-extrabold text-foreground">
            Dashboard ภาพรวม
          </h1>
          <p className="text-muted-foreground text-sm">
            ข้อมูล ณ เวลาปัจจุบัน · รีเฟรชทุก 30 วินาที
          </p>
        </div>

        {/* Stats Cards */}
        {statsLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            {[...Array(4)].map((_, i) => (
              <div
                key={i}
                className="bg-white rounded-2xl border border-border p-5 animate-pulse"
              >
                <div className="h-4 bg-muted rounded w-2/3 mb-3" />
                <div className="h-8 bg-muted rounded w-1/2" />
              </div>
            ))}
          </div>
        ) : (
          <>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <StatCard
                icon={<Users size={20} />}
                label="ลงทะเบียนทั้งหมด"
                value={stats?.total ?? 0}
                color="text-primary"
                bg="bg-primary/10"
                onClick={() => navigate("/admin/participants?status=all")}
              />
              <StatCard
                icon={<CheckCircle2 size={20} />}
                label="อนุมัติแล้ว"
                value={stats?.approved ?? 0}
                color="text-emerald-600"
                bg="bg-emerald-100"
                onClick={() => navigate("/admin/participants?status=approved")}
              />
              <StatCard
                icon={<Clock size={20} />}
                label="รอตรวจสอบ"
                value={stats?.pending ?? 0}
                color="text-amber-600"
                bg="bg-amber-100"
                highlight={!!stats?.pending}
                onClick={() => navigate("/admin/participants?status=pending")}
              />
              <StatCard
                icon={<XCircle size={20} />}
                label="ไม่ผ่าน"
                value={stats?.rejected ?? 0}
                color="text-red-600"
                bg="bg-red-100"
                onClick={() => navigate("/admin/participants?status=rejected")}
              />
            </div>

            {/* Total guests */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-white rounded-2xl border border-border p-5 shadow-sm md:col-span-1">
                <div className="w-10 h-10 rounded-xl bg-violet-100 flex items-center justify-center text-violet-600 mb-3">
                  <Users size={20} />
                </div>
                <p className="text-2xl font-extrabold text-foreground">
                  {(stats?.totalGuests ?? 0).toLocaleString()}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  ผู้เข้าร่วมรวม (รวมผู้ติดตาม)
                </p>
              </div>

              {/* Quick Actions */}
              <div
                className="bg-primary/5 border border-primary/20 rounded-2xl p-4 flex flex-col justify-between cursor-pointer hover:bg-primary/10 transition-colors"
                onClick={() => navigate("/admin/scanner")}
              >
                <div className="flex items-center gap-2 mb-2">
                  <ScanLine size={18} className="text-primary" />
                  <span className="text-sm font-semibold text-primary">
                    สแกน QR Code
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">
                  เปิดกล้องสแกนเพื่อ Check-in หน้างาน
                </p>
              </div>

              <div
                className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 flex flex-col justify-between cursor-pointer hover:bg-emerald-100 transition-colors"
                onClick={handleExportAll}
              >
                <div className="flex items-center gap-2 mb-2">
                  <Download size={18} className="text-emerald-700" />
                  <span className="text-sm font-semibold text-emerald-700">
                    Export Excel
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">
                  ดาวน์โหลดรายชื่อทั้งหมด พร้อมสถิติ
                </p>
              </div>
            </div>

            {/* Province Stats */}
            {(stats?.byProvince?.length ?? 0) > 0 && (
              <div className="bg-white rounded-2xl border border-border p-5 shadow-sm mb-6">
                <div className="flex items-center gap-2 mb-4">
                  <MapPin size={18} className="text-primary" />
                  <h3 className="font-bold text-foreground">
                    จังหวัดที่มามากที่สุด
                  </h3>
                </div>
                <div className="space-y-2">
                  {stats?.byProvince?.slice(0, 5).map((item, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <span className="text-xs text-muted-foreground w-4">
                        {i + 1}
                      </span>
                      <div className="flex-1">
                        <div className="flex justify-between text-sm mb-1">
                          <span className="font-medium text-foreground">
                            {item.province || "ไม่ระบุ"}
                          </span>
                          <span className="text-muted-foreground">
                            {item.count} คน
                          </span>
                        </div>
                        <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-primary rounded-full transition-all duration-500"
                            style={{
                              width: `${Math.min(100, (item.count / (stats?.total || 1)) * 100)}%`,
                            }}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}

        {/* ─── Pending Queue ─────────────────────────────────────── */}
        <div className="mb-2">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Clock size={18} className="text-amber-600" />
              <h2 className="text-lg font-bold text-foreground">
                รอตรวจสอบสลิป
              </h2>
              {(pendingList?.length ?? 0) > 0 && (
                <span className="bg-amber-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                  {pendingList?.length}
                </span>
              )}
            </div>
            {(pendingList?.length ?? 0) > 0 && (
              <button
                onClick={() => navigate("/admin/participants?status=pending")}
                className="text-xs text-primary hover:underline"
              >
                ดูทั้งหมด →
              </button>
            )}
          </div>

          {pendingLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[...Array(2)].map((_, i) => (
                <div
                  key={i}
                  className="bg-white rounded-2xl border border-border p-4 animate-pulse"
                >
                  <div className="h-4 bg-muted rounded w-1/2 mb-3" />
                  <div className="h-32 bg-muted rounded-xl mb-3" />
                  <div className="h-8 bg-muted rounded-xl" />
                </div>
              ))}
            </div>
          ) : (pendingList?.length ?? 0) === 0 ? (
            <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-6 text-center">
              <CheckCircle2
                size={32}
                className="text-emerald-500 mx-auto mb-2"
              />
              <p className="font-semibold text-emerald-800">
                ไม่มีรายการรอตรวจสอบ
              </p>
              <p className="text-sm text-emerald-600 mt-1">
                ทุกรายการได้รับการดำเนินการแล้ว
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {pendingList?.map(p => (
                <PendingCard
                  key={p.id}
                  p={p}
                  onApprove={(id, note) => approveMutation.mutate({ id, note })}
                  onReject={(id, note) => rejectMutation.mutate({ id, note })}
                  onViewDetail={id => navigate(`/admin/participants/${id}`)}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function StatCard({
  icon,
  label,
  value,
  color,
  bg,
  highlight,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  color: string;
  bg: string;
  highlight?: boolean;
  onClick?: () => void;
}) {
  return (
    <div
      className={`bg-white rounded-2xl border p-5 shadow-sm transition-shadow ${
        highlight ? "border-amber-300 ring-2 ring-amber-200" : "border-border"
      } ${onClick ? "cursor-pointer hover:shadow-md" : ""}`}
      onClick={onClick}
    >
      <div
        className={`w-10 h-10 rounded-xl ${bg} flex items-center justify-center ${color} mb-3`}
      >
        {icon}
      </div>
      <p className="text-2xl font-extrabold text-foreground">
        {value.toLocaleString()}
      </p>
      <p className="text-xs text-muted-foreground mt-1">{label}</p>
    </div>
  );
}

function LoadingScreen() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="text-center">
        <div className="animate-spin text-3xl mb-3">⏳</div>
        <p className="text-muted-foreground">กำลังโหลด...</p>
      </div>
    </div>
  );
}
