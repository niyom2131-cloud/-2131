import { describe, expect, it } from "vitest";
import { NNSKHS2131_NAME_COUNT, NNSKHS2131_NAMES } from "./nnskhs2131Names";

describe("NNSKHS2131_NAMES", () => {
  it("เก็บรายชื่อจากไฟล์แนบครบ 79 รายชื่อโดยไม่มีชื่อซ้ำ", () => {
    expect(NNSKHS2131_NAME_COUNT).toBe(79);
    expect(new Set(NNSKHS2131_NAMES).size).toBe(NNSKHS2131_NAME_COUNT);
  });

  it("มีรายชื่อที่ใช้ตรวจสอบจากต้นฉบับ", () => {
    expect(NNSKHS2131_NAMES).toEqual(
      expect.arrayContaining([
        "ปรีชากูล คูณทรัพย์",
        "นิยม สมาคม",
        "บุญนาก พรมมาลุน",
      ])
    );
  });

  it("เก็บเฉพาะชื่อ-นามสกุลโดยไม่มีเลขลำดับ", () => {
    expect(NNSKHS2131_NAMES.every(name => !/[0-9๐-๙]/.test(name))).toBe(true);
  });
});
