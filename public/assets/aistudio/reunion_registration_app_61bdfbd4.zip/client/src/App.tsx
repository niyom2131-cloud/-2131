import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Register from "./pages/Register";
import ThankYou from "./pages/ThankYou";
import CheckStatus from "./pages/CheckStatus";
import AdminLogin from "./pages/AdminLogin";
import AdminDashboard from "./pages/AdminDashboard";
import AdminParticipants from "./pages/AdminParticipants";
import AdminParticipantDetail from "./pages/AdminParticipantDetail";
import AdminQrScanner from "./pages/AdminQrScanner";
import AdminRegistration from "./pages/AdminRegistration";
import MyQrCode from "./pages/MyQrCode";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/register" component={Register} />
      <Route path="/thank-you/:id" component={ThankYou} />
      <Route path="/check-status" component={CheckStatus} />
      <Route path="/my-qr" component={MyQrCode} />
      <Route path="/admin" component={AdminLogin} />
      <Route path="/admin/dashboard" component={AdminDashboard} />
      <Route path="/admin/participants" component={AdminParticipants} />
      <Route
        path="/admin/participants/:id"
        component={AdminParticipantDetail}
      />
      <Route path="/admin/register" component={AdminRegistration} />
      <Route path="/admin/scanner" component={AdminQrScanner} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster richColors position="top-center" />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
