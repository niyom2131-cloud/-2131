import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import {
  createParticipant,
  deleteParticipant,
  getParticipantById,
  updateParticipant,
} from "./db";
import { storagePut } from "./storage";

// Mock db helpers
vi.mock("./db", () => ({
  createParticipant: vi.fn().mockResolvedValue(1),
  getParticipantByPhone: vi.fn().mockResolvedValue(null),
  getParticipantById: vi.fn().mockResolvedValue(null),
  getAllParticipants: vi.fn().mockResolvedValue([]),
  updateParticipant: vi.fn().mockResolvedValue(undefined),
  deleteParticipant: vi.fn().mockResolvedValue(undefined),
  getParticipantStats: vi.fn().mockResolvedValue({
    total: 0,
    approved: 0,
    pending: 0,
    rejected: 0,
    totalGuests: 0,
    byProvince: [],
    byFood: [],
    byShirt: [],
  }),
  getParticipantByQrToken: vi.fn().mockResolvedValue(null),
}));

// Mock storage
vi.mock("./storage", () => ({
  storagePut: vi
    .fn()
    .mockResolvedValue({ key: "test-key", url: "/manus-storage/test-key" }),
}));

// Mock notification
vi.mock("./_core/notification", () => ({
  notifyOwner: vi.fn().mockResolvedValue(true),
}));

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

function createAdminContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "admin-user",
      email: "admin@example.com",
      name: "Admin User",
      loginMethod: "manus",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

function createUserContext(): TrpcContext {
  return {
    user: {
      id: 2,
      openId: "regular-user",
      email: "user@example.com",
      name: "Regular User",
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

describe("registration.create", () => {
  it("creates a new participant successfully", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.registration.create({
      fullName: "สมชาย ใจดี",
      phone: "0812345678",
      guestCount: 1,
      foodType: "general",
      shirtSize: "L",
    });

    expect(result.success).toBe(true);
    expect(result.id).toBe(1);
  });

  it("accepts a name typed outside the suggested name list", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const typedName = "ผู้สมัครใหม่ นอกบัญชี";

    await expect(
      caller.registration.create({
        fullName: typedName,
        phone: "0899999999",
        guestCount: 0,
      })
    ).resolves.toEqual({ success: true, id: 1 });

    expect(createParticipant).toHaveBeenCalledWith(
      expect.objectContaining({ fullName: typedName })
    );
  });

  it("validates required fields", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.registration.create({
        fullName: "ก",
        phone: "0812345678",
        guestCount: 0,
        foodType: "general",
        shirtSize: "M",
      })
    ).rejects.toThrow();
  });
});

describe("registration.checkStatus", () => {
  it("returns null when phone not found", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.registration.checkStatus({
      phone: "0000000000",
    });
    expect(result).toBeNull();
  });
});

describe("admin procedures", () => {
  it("rejects non-admin users from stats", async () => {
    const ctx = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(caller.admin.stats()).rejects.toThrow(
      "เฉพาะผู้ดูแลระบบเท่านั้น"
    );
  });

  it("allows admin to get stats", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const stats = await caller.admin.stats();
    expect(stats).toHaveProperty("total");
    expect(stats).toHaveProperty("approved");
    expect(stats).toHaveProperty("pending");
  });

  it("rejects non-admin from listing participants", async () => {
    const ctx = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(caller.admin.list({ status: "all" })).rejects.toThrow(
      "เฉพาะผู้ดูแลระบบเท่านั้น"
    );
  });

  it("allows admin to list participants", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.list({ status: "all" });
    expect(Array.isArray(result)).toBe(true);
  });

  it("allows admin to register on behalf of a participant", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    const typedName = "ผู้เข้าร่วมที่ Admin เพิ่มเอง";

    const result = await caller.admin.createRegistration({
      fullName: typedName,
      phone: "0812345678",
      guestCount: 2,
      paymentAmount: 3000,
    });

    expect(result).toEqual({ success: true, id: 1 });
    expect(createParticipant).toHaveBeenCalledWith(
      expect.objectContaining({
        fullName: typedName,
        phone: "0812345678",
        guestCount: 2,
        totalCount: 3,
        paymentAmount: 3000,
        status: "pending",
      })
    );
  });

  it("allows admin to update participant details", async () => {
    vi.mocked(getParticipantById).mockResolvedValue({ id: 1 } as any);
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    await caller.admin.update({
      id: 1,
      fullName: "สมชาย ใจดี",
      phone: "0812345678",
      guestCount: 2,
      paymentAmount: 3000,
    });

    expect(updateParticipant).toHaveBeenCalledWith(
      1,
      expect.objectContaining({
        fullName: "สมชาย ใจดี",
        phone: "0812345678",
        guestCount: 2,
        totalCount: 3,
        paymentAmount: 3000,
      })
    );
  });

  it("allows admin to replace a participant slip", async () => {
    vi.mocked(getParticipantById).mockResolvedValue({ id: 1 } as any);
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    await caller.admin.update({
      id: 1,
      slipBase64: Buffer.from("new-slip").toString("base64"),
      slipMimeType: "image/png",
    });

    expect(storagePut).toHaveBeenCalled();
    expect(updateParticipant).toHaveBeenCalledWith(
      1,
      expect.objectContaining({
        slipKey: "test-key",
        slipUrl: "/manus-storage/test-key",
      })
    );
  });

  it("requires an existing participant before admin deletes", async () => {
    vi.mocked(getParticipantById).mockResolvedValue({ id: 1 } as any);
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    await expect(caller.admin.delete({ id: 1 })).resolves.toEqual({
      success: true,
    });
    expect(deleteParticipant).toHaveBeenCalledWith(1);
  });
});

describe("auth.logout", () => {
  it("clears session cookie", async () => {
    const ctx = createPublicContext();
    const clearedCookies: string[] = [];
    ctx.res.clearCookie = (name: string) => {
      clearedCookies.push(name);
    };

    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();

    expect(result.success).toBe(true);
    expect(clearedCookies.length).toBeGreaterThan(0);
  });
});
