import { eq, desc, like, or, count, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, participants, InsertParticipant, Participant } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ===== USER HELPERS =====
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot upsert user: database not available"); return; }
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
    if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
    else if (user.openId === ENV.ownerOpenId) { values.role = 'admin'; updateSet.role = 'admin'; }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ===== PARTICIPANT HELPERS =====
export async function createParticipant(data: InsertParticipant): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(participants).values(data);
  return (result[0] as any).insertId as number;
}

export async function getParticipantById(id: number): Promise<Participant | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(participants).where(eq(participants.id, id)).limit(1);
  return result[0];
}

export async function getParticipantByPhone(phone: string): Promise<Participant | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(participants).where(eq(participants.phone, phone)).limit(1);
  return result[0];
}

export async function getAllParticipants(search?: string): Promise<Participant[]> {
  const db = await getDb();
  if (!db) return [];
  if (search) {
    return db.select().from(participants).where(
      or(
        like(participants.fullName, `%${search}%`),
        like(participants.phone, `%${search}%`),
        like(participants.nickname, `%${search}%`),
        like(participants.classYear, `%${search}%`),
        like(participants.province, `%${search}%`),
      )
    ).orderBy(desc(participants.createdAt));
  }
  return db.select().from(participants).orderBy(desc(participants.createdAt));
}

export async function updateParticipant(id: number, data: Partial<InsertParticipant>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(participants).set(data).where(eq(participants.id, id));
}

export async function deleteParticipant(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(participants).where(eq(participants.id, id));
}

export async function getParticipantStats() {
  const db = await getDb();
  if (!db) return { total: 0, approved: 0, pending: 0, rejected: 0, totalGuests: 0, byProvince: [], byFood: [], byShirt: [] };

  const [totalRow] = await db.select({ count: count() }).from(participants);
  const [approvedRow] = await db.select({ count: count() }).from(participants).where(eq(participants.status, 'approved'));
  const [pendingRow] = await db.select({ count: count() }).from(participants).where(eq(participants.status, 'pending'));
  const [rejectedRow] = await db.select({ count: count() }).from(participants).where(eq(participants.status, 'rejected'));
  const [guestsRow] = await db.select({ total: sql<number>`SUM(totalCount)` }).from(participants).where(eq(participants.status, 'approved'));

  const byProvince = await db
    .select({ province: participants.province, count: count() })
    .from(participants)
    .groupBy(participants.province)
    .orderBy(desc(count()))
    .limit(10);

  const byFood = await db
    .select({ foodType: participants.foodType, count: count() })
    .from(participants)
    .groupBy(participants.foodType);

  const byShirt = await db
    .select({ shirtSize: participants.shirtSize, count: count() })
    .from(participants)
    .groupBy(participants.shirtSize);

  return {
    total: totalRow?.count ?? 0,
    approved: approvedRow?.count ?? 0,
    pending: pendingRow?.count ?? 0,
    rejected: rejectedRow?.count ?? 0,
    totalGuests: Number(guestsRow?.total ?? 0),
    byProvince,
    byFood,
    byShirt,
  };
}

export async function getParticipantByQrToken(token: string): Promise<Participant | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(participants).where(eq(participants.qrToken, token)).limit(1);
  return result[0];
}
