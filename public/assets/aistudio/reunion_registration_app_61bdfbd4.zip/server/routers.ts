import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { notifyOwner } from "./_core/notification";
import { nanoid } from "nanoid";
import {
  createParticipant,
  getParticipantById,
  getParticipantByPhone,
  getAllParticipants,
  updateParticipant,
  deleteParticipant,
  getParticipantStats,
  getParticipantByQrToken,
} from "./db";
import { storagePut } from "./storage";

// Admin middleware
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "เฉพาะผู้ดูแลระบบเท่านั้น",
    });
  }
  return next({ ctx });
});

const foodTypeLabel: Record<string, string> = {
  general: "อาหารทั่วไป",
  muslim: "อาหารมุสลิม",
  vegetarian: "มังสวิรัติ",
};

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ===== REGISTRATION =====
  registration: router({
    // ลงทะเบียนใหม่ (public)
    create: publicProcedure
      .input(
        z.object({
          fullName: z.string().min(2, "กรุณากรอกชื่อ-นามสกุล"),
          nickname: z.string().optional(),
          classYear: z.string().optional(),
          phone: z.string().min(9, "กรุณากรอกเบอร์โทรศัพท์"),
          lineId: z.string().optional(),
          province: z.string().optional(),
          guestCount: z.number().min(0).default(0),
          foodType: z.enum(["general", "muslim", "vegetarian"]).optional(),
          shirtSize: z.enum(["S", "M", "L", "XL", "XXL"]).optional(),
          message: z.string().optional(),
          paymentAmount: z.number().optional(),
          paymentDate: z.number().optional(),
          slipBase64: z.string().optional(), // base64 encoded image
          slipMimeType: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        let slipKey: string | undefined;
        let slipUrl: string | undefined;

        // อัปโหลดสลิปถ้ามี
        if (input.slipBase64 && input.slipMimeType) {
          const buffer = Buffer.from(input.slipBase64, "base64");
          const ext = input.slipMimeType.split("/")[1] || "jpg";
          const key = `slips/${Date.now()}-${nanoid(8)}.${ext}`;
          const result = await storagePut(key, buffer, input.slipMimeType);
          slipKey = result.key;
          slipUrl = result.url;
        }

        const totalCount = 1 + (input.guestCount || 0);
        const id = await createParticipant({
          fullName: input.fullName,
          nickname: input.nickname,
          classYear: input.classYear,
          phone: input.phone,
          lineId: input.lineId,
          province: input.province,
          guestCount: input.guestCount || 0,
          totalCount,
          foodType: input.foodType,
          shirtSize: input.shirtSize,
          message: input.message,
          paymentAmount: input.paymentAmount,
          paymentDate: input.paymentDate,
          slipKey,
          slipUrl,
          status: "pending",
        });

        // แจ้งเตือน Admin
        await notifyOwner({
          title: "🎖️ มีผู้ลงทะเบียนใหม่!",
          content: `${input.fullName} (${input.nickname || "-"}) จ.${input.province || "-"}\nโทร: ${input.phone} | LINE: ${input.lineId || "-"}\nผู้ติดตาม: ${input.guestCount} คน | รวม: ${totalCount} คน${input.paymentAmount ? `\nยอดโอน: ${input.paymentAmount.toLocaleString()} บาท` : ""}`,
        }).catch(() => {});

        return { success: true, id };
      }),

    // ตรวจสอบสถานะด้วยเบอร์โทร (public)
    checkStatus: publicProcedure
      .input(z.object({ phone: z.string() }))
      .query(async ({ input }) => {
        const p = await getParticipantByPhone(input.phone);
        if (!p) return null;
        return {
          id: p.id,
          fullName: p.fullName,
          nickname: p.nickname,
          status: p.status,
          qrToken: p.status === "approved" ? p.qrToken : undefined,
          createdAt: p.createdAt,
        };
      }),

    // ดู QR Code ของตัวเอง (ต้องได้รับอนุมัติแล้ว)
    getMyQr: publicProcedure
      .input(z.object({ phone: z.string() }))
      .query(async ({ input }) => {
        const p = await getParticipantByPhone(input.phone);
        if (!p)
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "ไม่พบข้อมูลการลงทะเบียน",
          });
        if (p.status !== "approved")
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "ยังไม่ได้รับการอนุมัติ",
          });
        return {
          qrToken: p.qrToken ?? "",
          fullName: p.fullName,
          nickname: p.nickname ?? "",
          shirtSize: p.shirtSize,
        };
      }),
  }),

  // ===== ADMIN =====
  admin: router({
    // สถิติ Dashboard
    stats: adminProcedure.query(async () => {
      return getParticipantStats();
    }),

    // รายชื่อทั้งหมด
    list: adminProcedure
      .input(
        z.object({
          search: z.string().optional(),
          status: z
            .enum(["all", "pending", "approved", "rejected"])
            .default("all"),
        })
      )
      .query(async ({ input }) => {
        const all = await getAllParticipants(input.search);
        if (input.status === "all") return all;
        return all.filter(p => p.status === input.status);
      }),

    // รายละเอียดผู้ลงทะเบียน
    getById: adminProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const p = await getParticipantById(input.id);
        if (!p) throw new TRPCError({ code: "NOT_FOUND" });
        return p;
      }),

    // อนุมัติการชำระเงิน
    approve: adminProcedure
      .input(z.object({ id: z.number(), note: z.string().optional() }))
      .mutation(async ({ input }) => {
        const p = await getParticipantById(input.id);
        if (!p) throw new TRPCError({ code: "NOT_FOUND" });
        const qrToken = p.qrToken || nanoid(20);
        await updateParticipant(input.id, {
          status: "approved",
          adminNote: input.note,
          qrToken,
        });
        return { success: true, qrToken };
      }),

    // ปฏิเสธการชำระเงิน
    reject: adminProcedure
      .input(z.object({ id: z.number(), note: z.string().optional() }))
      .mutation(async ({ input }) => {
        await updateParticipant(input.id, {
          status: "rejected",
          adminNote: input.note,
        });
        return { success: true };
      }),

    // ลงทะเบียนแทนผู้เข้าร่วม (ผู้ดูแลเท่านั้น)
    createRegistration: adminProcedure
      .input(
        z.object({
          fullName: z.string().trim().min(2, "กรุณากรอกชื่อ-นามสกุล"),
          nickname: z.string().trim().optional(),
          phone: z.string().trim().min(9, "กรุณากรอกเบอร์โทรศัพท์"),
          lineId: z.string().trim().optional(),
          province: z.string().trim().optional(),
          guestCount: z.number().int().min(0).max(10).default(0),
          message: z.string().trim().optional(),
          paymentAmount: z.number().int().min(0).optional(),
          paymentDate: z.number().int().optional(),
          slipBase64: z.string().optional(),
          slipMimeType: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        let slipKey: string | undefined;
        let slipUrl: string | undefined;

        if (input.slipBase64 && input.slipMimeType) {
          const buffer = Buffer.from(input.slipBase64, "base64");
          const ext = input.slipMimeType.split("/")[1] || "jpg";
          const key = `slips/${Date.now()}-${nanoid(8)}.${ext}`;
          const result = await storagePut(key, buffer, input.slipMimeType);
          slipKey = result.key;
          slipUrl = result.url;
        }

        const totalCount = 1 + input.guestCount;
        const id = await createParticipant({
          fullName: input.fullName,
          nickname: input.nickname || undefined,
          phone: input.phone,
          lineId: input.lineId || undefined,
          province: input.province || undefined,
          guestCount: input.guestCount,
          totalCount,
          message: input.message || undefined,
          paymentAmount: input.paymentAmount,
          paymentDate: input.paymentDate,
          slipKey,
          slipUrl,
          status: "pending",
        });

        return { success: true, id };
      }),

    // แก้ไขข้อมูล
    update: adminProcedure
      .input(
        z.object({
          id: z.number(),
          fullName: z
            .string()
            .trim()
            .min(2, "กรุณากรอกชื่อ-นามสกุล")
            .optional(),
          nickname: z.string().optional(),
          classYear: z.string().optional(),
          phone: z.string().trim().min(9, "กรุณากรอกเบอร์โทรศัพท์").optional(),
          lineId: z.string().optional(),
          province: z.string().optional(),
          guestCount: z.number().int().min(0).max(10).optional(),
          foodType: z.enum(["general", "muslim", "vegetarian"]).optional(),
          shirtSize: z.enum(["S", "M", "L", "XL", "XXL"]).optional(),
          message: z.string().optional(),
          paymentAmount: z.number().int().min(0).nullable().optional(),
          paymentDate: z.number().int().nullable().optional(),
          slipBase64: z.string().optional(),
          slipMimeType: z.string().optional(),
          adminNote: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, slipBase64, slipMimeType, ...data } = input;
        const participant = await getParticipantById(id);
        if (!participant)
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "ไม่พบข้อมูลผู้ลงทะเบียน",
          });
        const updates: Record<string, unknown> = {};
        for (const [k, v] of Object.entries(data)) {
          if (v !== undefined) updates[k] = v;
        }
        if (updates.guestCount !== undefined) {
          updates.totalCount = 1 + (updates.guestCount as number);
        }
        if (slipBase64 && slipMimeType) {
          const buffer = Buffer.from(slipBase64, "base64");
          const ext = slipMimeType.split("/")[1] || "jpg";
          const key = `slips/${Date.now()}-${nanoid(8)}.${ext}`;
          const result = await storagePut(key, buffer, slipMimeType);
          updates.slipKey = result.key;
          updates.slipUrl = result.url;
        }
        await updateParticipant(id, updates as any);
        return { success: true };
      }),

    // ลบผู้ลงทะเบียน
    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const participant = await getParticipantById(input.id);
        if (!participant)
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "ไม่พบข้อมูลผู้ลงทะเบียน",
          });
        await deleteParticipant(input.id);
        return { success: true };
      }),

    // Check-in ด้วย QR Token
    checkIn: adminProcedure
      .input(z.object({ qrToken: z.string() }))
      .mutation(async ({ input }) => {
        const p = await getParticipantByQrToken(input.qrToken);
        if (!p)
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "ไม่พบ QR Code นี้",
          });
        if (p.status !== "approved")
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "ผู้ลงทะเบียนยังไม่ได้รับอนุมัติ",
          });
        if (p.checkedIn === 1) {
          return { success: false, alreadyCheckedIn: true, participant: p };
        }
        await updateParticipant(p.id, {
          checkedIn: 1,
          checkedInAt: Date.now(),
        });
        return { success: true, alreadyCheckedIn: false, participant: p };
      }),

    // Export ข้อมูลเป็น Excel
    exportData: adminProcedure
      .input(
        z.object({
          status: z
            .enum(["all", "pending", "approved", "rejected"])
            .default("all"),
        })
      )
      .query(async ({ input }) => {
        const all = await getAllParticipants();
        const filtered =
          input.status === "all"
            ? all
            : all.filter(p => p.status === input.status);
        return filtered.map((p, i) => ({
          ลำดับ: i + 1,
          "ชื่อ-นามสกุล": p.fullName,
          ชื่อเล่น: p.nickname || "",
          โทรศัพท์: p.phone,
          "LINE ID": p.lineId || "",
          จังหวัด: p.province || "",
          "จำนวนผู้ติดตาม (คน)": p.guestCount,
          "รวมทั้งหมด (คน)": p.totalCount,
          ข้อความถึงเพื่อน: p.message || "",
          "ยอดโอน (บาท)": p.paymentAmount || 0,
          วันที่โอน: p.paymentDate
            ? new Date(p.paymentDate).toLocaleDateString("th-TH")
            : "",
          สถานะ:
            p.status === "approved"
              ? "อนุมัติแล้ว"
              : p.status === "rejected"
                ? "ปฏิเสธ"
                : "รอตรวจสอบ",
          "หมายเหตุ Admin": p.adminNote || "",
          "Check-in": p.checkedIn === 1 ? "เข้างานแล้ว" : "ยังไม่เข้า",
          เวลา_checkin: p.checkedInAt
            ? new Date(p.checkedInAt).toLocaleString("th-TH")
            : "",
          ลงทะเบียนเมื่อ: new Date(p.createdAt).toLocaleString("th-TH"),
        }));
      }),
  }),
});

export type AppRouter = typeof appRouter;
