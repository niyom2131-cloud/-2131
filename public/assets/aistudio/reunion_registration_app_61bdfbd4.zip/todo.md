# ระบบลงทะเบียนร่วมงานเลี้ยงรุ่น นนส.เหล่าทหารขนส่ง 2569 - TODO

## Phase 1: Database Schema & Backend API

- [x] สร้าง participants table ใน drizzle/schema.ts
- [x] สร้าง migration SQL และ apply ผ่าน webdev_execute_sql
- [x] สร้าง db helpers ใน server/db.ts
- [x] สร้าง tRPC router สำหรับ registration (create, checkStatus, getMyQr)
- [x] สร้าง tRPC router สำหรับ admin (stats, list, getById, approve, reject, update, delete, checkIn, exportData)
- [x] ระบบอัปโหลดสลิปผ่าน S3 storage
- [x] ระบบแจ้งเตือน Admin เมื่อมีการลงทะเบียนใหม่ (notifyOwner)
- [x] เขียน vitest สำหรับ backend (9 tests passed)

## Phase 2: Frontend - Public Pages

- [x] ปรับ index.css ตาม Design System (pale cool gray, pastel blue/pink, sans-serif Sarabun)
- [x] หน้าแรก (Home) - โลโก้, กำหนดการ, ขั้นตอน, ปุ่มลงทะเบียน
- [x] หน้าลงทะเบียน 3 ขั้นตอน (ข้อมูลส่วนตัว, การเข้าร่วม, ชำระเงิน)
- [x] อัปโหลดสลิปโอนเงิน (Base64 → S3 Storage)
- [x] หน้าขอบคุณหลังลงทะเบียนสำเร็จ
- [x] ตรวจสอบสถานะการลงทะเบียน (ค้นหาด้วยเบอร์โทร)
- [x] หน้าแสดง QR Code (เฉพาะผู้ที่ได้รับอนุมัติ)

## Phase 3: Admin Dashboard

- [x] หน้า Admin Login (ใช้ Manus OAuth)
- [x] Admin Dashboard - สถิติภาพรวม (ภาพรวม, รายชื่อ, สแกน QR)
- [x] รายชื่อผู้ลงทะเบียนทั้งหมด + ค้นหา + กรองสถานะ
- [x] หน้ารายละเอียดผู้เข้าร่วม + ดูสลิป
- [x] ระบบอนุมัติ/ปฏิเสธการชำระเงิน พร้อมหมายเหตุ
- [x] Export Excel รายชื่อผู้ลงทะเบียน (ใช้ xlsx library)
- [x] แก้ไขข้อมูลผู้ลงทะเบียน
- [x] ลบผู้ลงทะเบียน

## Phase 4: QR Code & Notifications

- [x] สร้าง QR Code เฉพาะผู้ที่ได้รับอนุมัติ (nanoid token)
- [x] หน้าแสดง QR Code สำหรับผู้ลงทะเบียน (qrcode library)
- [x] ระบบสแกน QR Code หน้างาน (Admin Check-in)
- [x] การแจ้งเตือน Admin แบบ real-time (notifyOwner ทุกครั้งที่มีการลงทะเบียน)

## Phase 5: Polish & Testing

- [x] Responsive design ทุกหน้า (mobile-first, รองรับ 390px - 1280px)
- [x] Loading states และ skeleton loaders
- [x] Error handling ครบถ้วน
- [x] Animation และ micro-interactions (button press, transitions)
- [x] TypeScript check ผ่าน (0 errors)
- [x] Vitest tests ผ่าน (9/9)
- [x] Checkpoint สุดท้าย

## Phase 6: Admin Dashboard Upgrade (ระยะที่ 2)

- [x] Admin Dashboard - Pending Queue พร้อม Slip Lightbox inline
- [x] Admin Dashboard - Approve/Reject inline พร้อม note
- [x] Export Excel - คอลัมน์ภาษาไทย, 2 Sheet (รายชื่อ+สรุปสถิติ)
- [x] ปรับ exportData ให้ตัดคอลัมน์เก่า (รุ่น/เหล่า, ประเภทอาหาร, ขนาดเสื้อ)
- [x] รายชื่อผู้ลงทะเบียน - ปรับ UI ให้สวยงาม, filter status, search

## Phase 7: รายชื่อผู้ลงทะเบียน

- [x] นำเข้ารายชื่อจากไฟล์แนบ `namelist_nnskhs2131.csv` จำนวน 79 รายชื่อ
- [x] ปรับช่องชื่อ-นามสกุลเป็นค้นหาและเลือกจากรายชื่อที่กำหนด

## Phase 8: การจัดการผู้ลงทะเบียนโดยผู้ดูแล

- [x] เพิ่มหน้าให้ผู้ดูแลลงทะเบียนแทนผู้เข้าร่วม
- [x] เพิ่มหน้าจอแก้ไขข้อมูลผู้ลงทะเบียนสำหรับผู้ดูแล
- [x] เพิ่มการลบข้อมูลผู้ลงทะเบียนพร้อมการยืนยัน

## Phase 9: ความยืดหยุ่นของข้อมูลผู้ลงทะเบียน
- [x] ปรับช่องชื่อ-นามสกุลให้พิมพ์ชื่อเองได้ พร้อมรายชื่อแนะนำเดิม
- [x] ปรับหน้าลงทะเบียนแทนของ Admin ให้พิมพ์ชื่อเองได้ พร้อมรายชื่อแนะนำเดิม
