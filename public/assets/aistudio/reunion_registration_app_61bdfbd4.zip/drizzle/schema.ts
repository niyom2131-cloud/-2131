import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  bigint,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ตารางผู้ลงทะเบียน
export const participants = mysqlTable("participants", {
  id: int("id").autoincrement().primaryKey(),

  // ข้อมูลส่วนตัว
  fullName: varchar("fullName", { length: 255 }).notNull(),
  nickname: varchar("nickname", { length: 100 }),
  classYear: varchar("classYear", { length: 100 }), // รุ่น/หมู่เรียน
  phone: varchar("phone", { length: 20 }).notNull(),
  lineId: varchar("lineId", { length: 100 }),
  province: varchar("province", { length: 100 }),

  // ข้อมูลการเข้าร่วม
  guestCount: int("guestCount").default(0).notNull(), // จำนวนผู้ติดตาม
  totalCount: int("totalCount").default(1).notNull(), // จำนวนรวม (ตัวเอง + ผู้ติดตาม)
  foodType: mysqlEnum("foodType", ["general", "muslim", "vegetarian"])
    .default("general")
    .notNull(),
  shirtSize: mysqlEnum("shirtSize", ["S", "M", "L", "XL", "XXL"]).default("M").notNull(),

  // ข้อความถึงเพื่อน
  message: text("message"),

  // การชำระเงิน
  paymentAmount: int("paymentAmount"), // จำนวนเงิน (บาท)
  paymentDate: bigint("paymentDate", { mode: "number" }), // วันที่โอน (timestamp ms)
  slipKey: varchar("slipKey", { length: 500 }), // S3 key ของสลิป
  slipUrl: varchar("slipUrl", { length: 1000 }), // URL ของสลิป

  // สถานะ
  status: mysqlEnum("status", ["pending", "approved", "rejected"])
    .default("pending")
    .notNull(),
  adminNote: text("adminNote"), // หมายเหตุจาก Admin

  // QR Code
  qrToken: varchar("qrToken", { length: 100 }), // token สำหรับ QR Code
  checkedIn: int("checkedIn").default(0).notNull(), // 0 = ยังไม่ check-in, 1 = check-in แล้ว
  checkedInAt: bigint("checkedInAt", { mode: "number" }), // เวลา check-in

  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Participant = typeof participants.$inferSelect;
export type InsertParticipant = typeof participants.$inferInsert;
